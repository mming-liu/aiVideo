﻿import json, sys
sys.path.insert(0, ".tmp/s19_ch2")
import common
from shared import presentation_contract as pc
plan = common.load_plan()
view, probs = pc.view_from_plan(plan)
print("probs", probs)
print("view keys", list(view))
print("beat0", json.dumps(view["beats"][0], ensure_ascii=False))
print("dlg0", json.dumps(view["dialogue_units"][0], ensure_ascii=False))
print("narr0", json.dumps(view["narration_units"][0], ensure_ascii=False))
print("fact0", json.dumps(view["frozen_facts"][0], ensure_ascii=False))
print("bind0", json.dumps(view["fact_bindings"][0], ensure_ascii=False))
print("basis keys", list(view["plan_basis"]))
print("capacity", view.get("carrier_capacity"), "mode", view.get("mode"), "event_binding", view.get("event_binding"))
print("proj equal", pc.plan_from_view(view) == plan)
