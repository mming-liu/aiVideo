# -*- coding: utf-8 -*-
"""S25：生成可阅读的前后对照（基线 20 声 → 候选 10 声；事实承载前后）."""
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import common  # noqa: E402

from step01_script_gen.plan_feasibility import (fact_carrier, plan_dialogue_lines,
                                                plan_narration_entries, plan_voice_entries,
                                                voice_entry_costs)


def main():
    base = common.load_plan()
    cand = common.read_json(common.HERE / "candidate_plan.json")
    base_rows = voice_entry_costs(base)
    cand_rows = voice_entry_costs(cand)
    base_texts = {r["text"]: r for r in base_rows}
    cand_texts = {r["text"]: r for r in cand_rows}
    lines = ["# 第二章声音重分配：前后对照（S25 可评阅产物）", "",
             "基线：`.tmp/s14b/runs/s12_ch2/rebound_plan.json`（SHA-256 `fb8ac9f7…adec`）",
             "候选：`.tmp/s19_ch2/candidate_plan.json`（SHA-256 `%s`）" % common.sha256_file(
                 common.HERE / "candidate_plan.json"),
             "",
             "| 项 | 基线 | 候选 |", "|---|---:|---:|",
             "| 声音条数 | %d | %d |" % (len(base_rows), len(cand_rows)),
             "| 发声合计 | %.2fs | %.2fs |" % (sum(r["body_sec"] for r in base_rows),
                                              sum(r["body_sec"] for r in cand_rows)),
             "| 汉字 | %d | %d |" % (sum(len(r["text"]) for r in base_rows),
                                     sum(len(r["text"]) for r in cand_rows)),
             "| 不可单镜表示 | %d | %d |" % (sum(1 for r in base_rows if not r["representable"]),
                                           sum(1 for r in cand_rows if not r["representable"])),
             "| 节拍 | %d | %d |" % (len(base.get("shot_beats") or []),
                                    len(cand.get("shot_beats") or [])),
             "| 事实 | %d | %d |" % (len(base.get("required_facts") or []),
                                    len(cand.get("required_facts") or [])),
             "", "## 一、保留下来的 10 条声音（逐字）", "",
             "| 编号 | 说话人/载体 | 估时(含前缀) | 正文估时 | 正文 |", "|---|---|---:|---:|---|"]
    spk = {str(u.get("echo_text")): str(u.get("speaker") or "") for u in (cand.get("voice_units") or [])}
    for r in cand_rows:
        lines.append("| %s | %s | %.2fs | %.2fs | %s |" % (
            r["id"], spk.get(r["text"], "") or "（旁白）", r["est_sec"], r["body_sec"], r["text"]))
    lines += ["", "## 二、被撤下的基线声音（不承载这 12 条事实，或由画面替代）", "",
              "| 基线编号 | 估时 | 正文 | 处理 |", "|---|---:|---|---|"]
    for r in base_rows:
        if r["text"] in cand_texts:
            continue
        why = "压缩合并" if any(r["text"] in t for t in cand_texts) else "撤下（非 12 条事实内容）"
        lines.append("| %s | %.2fs | %s | %s |" % (r["id"], r["body_sec"], r["text"][:60], why))
    lines += ["", "## 三、12 条事实的承载前/后", "",
              "| UID | 基线承载 | 候选承载 |", "|---|---|---|"]
    for i, (b, c) in enumerate(zip(base.get("required_facts") or [],
                                   cand.get("required_facts") or []), 1):
        lines.append("| f%02d | %s | %s |" % (i, fact_carrier(b), fact_carrier(c)))
    lines += ["", "## 四、候选的 20 条节拍", ""]
    for i, b in enumerate(cand.get("shot_beats") or [], 1):
        lines.append("%d. %s" % (i, b))
    out = common.HERE / "s25_compare.md"
    out.write_text("\n".join(lines) + "\n", encoding="utf-8")
    print("wrote", out, "lines", len(lines))


if __name__ == "__main__":
    main()
