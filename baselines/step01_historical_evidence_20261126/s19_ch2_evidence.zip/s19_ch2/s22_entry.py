# -*- coding: utf-8 -*-
"""S22：候选经**实际入口**到达分镜请求（桩），并验证拒收路径零请求、零覆盖.

链路：候选 → 投影回读 → plan_acceptance_problems → check_plan_before_generation
      → gen_spy_script 请求捕获（runtime.create_service 打桩，不发任何网络请求）。
"""
import copy
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import common  # noqa: E402

from shared import presentation_contract as pc  # noqa: E402
from step01_script_gen import lightweight_plan as lw  # noqa: E402
from step01_script_gen.plan_feasibility import (  # noqa: E402
    PlanContractInvalidError, PlanInfeasibleError, check_plan_before_generation,
    voice_entry_costs)
from step01_script_gen.outline import plan_acceptance_problems  # noqa: E402
from step01_script_gen.orchestrator import runtime as _runtime  # noqa: E402

OUT = common.HERE / "s22_entry.json"


class FakeResult:
    def __init__(self, text=""):
        self.success = True
        self.text = text
        self.error = ""
        self.call_id = "offline-stub-call"
        self.finish_reason = "stop"
        self.truncated = False


class SpyService:
    """符合当轮协议的桩：只记录请求，绝不触碰传输层."""

    def __init__(self):
        self.requests = []

    def generate(self, req):
        self.requests.append({
            "system_prompt": req.system_prompt,
            "user_prompt": req.user_prompt,
            "model": req.model,
            "max_tokens": getattr(req, "max_tokens", None),
            "temperature": getattr(req, "temperature", None),
            "json_schema_name": ((req.json_schema or {}).get("name")
                                 if isinstance(req.json_schema, dict) else None),
        })
        return FakeResult(json.dumps({"shots": []}, ensure_ascii=False))


def _protection_hashes():
    manifest = common.read_json(common.FROZEN["protect"])
    rows = {}
    for rel, expected in manifest.items():
        p = common.ROOT / rel
        rows[rel] = common.sha256_file(p) if p.exists() else None
    for k in ("ledger_ch1", "ledger_ch2", "incident_log"):
        p = common.FROZEN[k]
        rows[str(p.relative_to(common.ROOT))] = common.sha256_file(p) if p.exists() else None
    return rows


def _stub_runtime(spy):
    _runtime.create_service = lambda *a, **k: spy        # type: ignore[assignment]


def _gen_capture(plan, novel):
    """走真实 `gen_spy_script` 入口；返回捕获到的请求（无请求 = None）."""
    from step01_script_gen.orchestrator.generation import gen_spy_script
    spy = SpyService()
    _stub_runtime(spy)
    try:
        gen_spy_script(novel, outline=plan)
    except Exception as exc:                                   # noqa: BLE001
        return spy, "%s: %s" % (type(exc).__name__, str(exc)[:200])
    return spy, ""


def _mutate(view, fn):
    v = copy.deepcopy(view)
    fn(v)
    return v


def main():
    common.assert_frozen()
    base = common.load_plan()
    novel = common.load_novel()
    cand = common.read_json(common.HERE / "candidate_plan.json")
    view = common.read_json(common.HERE / "candidate_view.json")
    before_guard = _protection_hashes()
    cand_sha_before = common.sha256_file(common.HERE / "candidate_plan.json")
    out_dir = common.ISOLATED_OUTPUT
    out_before = sorted(str(p) for p in out_dir.rglob("*") if p.is_file()) if out_dir.exists() else []

    checks = []

    def check(name, ok, detail=""):
        checks.append({"name": name, "ok": bool(ok), "detail": str(detail)[:400]})
        return ok

    # ---- 1. 合法候选：投影回读 + 统一验收 + 生成前检查 ----
    v2, vp = pc.view_from_plan(cand)
    check("projection_readback", v2 is not None and not vp, vp)
    check("projection_fixed_point", v2 is not None and pc.plan_from_view(v2) == cand)
    acc = plan_acceptance_problems(cand, novel_text=novel)
    check("plan_acceptance_empty", not acc, [p.get("code") for p in acc])
    rep = check_plan_before_generation(cand, chapter_dir=None, novel_text=novel)
    check("before_generation_feasible", rep.get("verdict") == "feasible", rep.get("verdict"))
    # 事实/说话人/来源谱系保留
    check("facts_12", len(cand.get("required_facts") or []) == 12)
    check("voice_units_10", len(cand.get("voice_units") or []) == 10)
    check("speakers_declared", all(u.get("speaker") for u in cand["voice_units"]))
    check("source_splits_kept",
          (cand.get("source_splits") or []) == (base.get("source_splits") or []))
    check("source_preservation_kept",
          (cand.get("source_preservation") or {}) == (base.get("source_preservation") or {}))
    check("no_stale_verification",
          cand.get("lightweight_plan", {}).get("content_verification") == "not_run"
          and "plan_verification" not in cand)
    # 声音元数据不残留：voice_units 与 dialogue_lines 一一对应（无旧 20 条残留）
    dlg = list(cand.get("dialogue_lines") or [])
    check("no_old_voice_metadata",
          [u["echo_text"] for u in cand["voice_units"] if u["source_kind"] == "novel_speech"] == dlg)
    # 引用闭合
    fact_text = "".join(cand.get("required_facts") or [])
    check("no_dangling_Beat0", "B0/" not in fact_text)
    check("all_facts_carried", all("｜承载：" in f for f in cand.get("required_facts") or []))

    # ---- 2. 实际分镜入口：请求捕获 ----
    spy, err = _gen_capture(cand, novel)
    check("scriptgen_no_error", not err, err)
    check("scriptgen_request_captured", len(spy.requests) == 1, len(spy.requests))
    req = spy.requests[0] if spy.requests else {}
    prompt = req.get("user_prompt") or ""
    costs = voice_entry_costs(cand)
    check("request_has_all_voices", all(c["text"] in prompt for c in costs))
    check("request_has_timing_total", "全章声音合计约 66.70s" in prompt,
          prompt[-300:])
    check("request_tail_is_timing", "全章声音合计约 66.70s" in prompt[-700:])
    check("request_schema_is_script", req.get("json_schema_name") == "storyboard_script")
    check("request_carries_facts", all(
        (f.split("｜原文证据")[0][:24] in prompt) for f in (cand.get("required_facts") or [])))
    check("request_carries_carrier_decls",
          "B12/画面" in prompt or "B12" in prompt)

    # ---- 3. 拒收对照：都不允许到达分镜请求 ----
    neg = {}

    def _neg(name, mutate_view=None, base_plan=base, novel_text=novel, expect=None):
        v = _mutate(view, mutate_view) if mutate_view else view
        plan, problems, changes = lw.compile_reallocated_plan(
            copy.deepcopy(base_plan), v, novel_text=novel_text)
        if plan is not None:
            # 编译通过也不许到达请求：生成前检查必须拦（或本用例本身应拒收）
            spy2 = SpyService()
            _stub_runtime(spy2)
            blocked = ""
            try:
                check_plan_before_generation(plan, chapter_dir=None, novel_text=novel_text)
                _gen_capture(plan, novel_text)
                reached = bool(spy2.requests)
            except (PlanContractInvalidError, PlanInfeasibleError) as exc:
                blocked = type(exc).__name__
                reached = False
            neg[name] = {"compiled": True, "blocked_at": blocked, "reached_request": reached,
                         "problems": [p.get("code") for p in problems]}
            return not reached
        codes = [p.get("code") for p in problems]
        neg[name] = {"compiled": False, "codes": codes,
                     "problems": [str(p.get("reason") or "")[:160] for p in problems[:3]]}
        return bool(codes) and (expect is None or expect in codes)

    ok_wrong_speaker = _neg("wrong_speaker", lambda v: v["voice_speakers"].__setitem__("d05", "刘旭"),
                            expect="realloc_speaker_attribution")
    check("reject_wrong_speaker", ok_wrong_speaker, neg["wrong_speaker"])

    def _drop_fact(v):
        v["fact_bindings"][11]["carriers"] = []
    ok_missing_fact = _neg("missing_obligation", _drop_fact,
                            expect="carrier_fact_missing")
    check("reject_missing_obligation", ok_missing_fact or neg["missing_obligation"].get("reached_request") is False,
          neg["missing_obligation"])

    def _wrong_ref(v):
        v["fact_bindings"][0]["carriers"].append({"kind": "visual", "uid": "b99"})
    ok_wrong_ref = _neg("wrong_ref", _wrong_ref, expect="carrier_fact_beat_missing")
    check("reject_wrong_ref", ok_wrong_ref, neg["wrong_ref"])

    stale_base = copy.deepcopy(base)
    stale_base["lightweight_plan"]["novel_digest"] = "0" * 64
    ok_stale = _neg("stale_identity", None, base_plan=stale_base,
                    expect="realloc_base_identity_invalid")
    check("reject_stale_identity", ok_stale, neg["stale_identity"])

    # 旧核验结果不得沿用：基线带 plan_verification=supported 时候选必须 invalidate
    with_old = copy.deepcopy(base)
    with_old["plan_verification"] = {"status": "ok", "facts": [{"verdict": "supported"}]}
    plan_old, probs_old, _ch = lw.compile_reallocated_plan(with_old, view, novel_text=novel)
    check("old_verification_not_inherited",
          plan_old is not None and "plan_verification" not in plan_old
          and plan_old["lightweight_plan"]["content_verification"] == "not_run",
          [p.get("code") for p in probs_old])

    # ---- 4. 保护核对：正式产物/账本未被写；候选文件未被覆盖 ----
    after_guard = _protection_hashes()
    changed = [k for k in before_guard if before_guard[k] != after_guard.get(k)]
    check("formal_artifacts_untouched", not changed, changed)
    check("candidate_not_overwritten",
          common.sha256_file(common.HERE / "candidate_plan.json") == cand_sha_before)
    out_after = sorted(str(p) for p in out_dir.rglob("*") if p.is_file()) if out_dir.exists() else []
    check("no_formal_cache_write", out_before == out_after, out_after[:5])

    payload = {"checks": checks,
               "all_ok": all(c["ok"] for c in checks),
               "request": {"chars": len(prompt), "model": req.get("model"),
                           "schema": req.get("json_schema_name"),
                           "tail": prompt[-420:]},
               "negative": neg}
    common.write_json(OUT, payload)
    for c in checks:
        print(("OK  " if c["ok"] else "FAIL"), c["name"], "|", c["detail"][:120])
    print("REQUESTS", len(spy.requests), "ALL_OK", payload["all_ok"])


if __name__ == "__main__":
    main()
