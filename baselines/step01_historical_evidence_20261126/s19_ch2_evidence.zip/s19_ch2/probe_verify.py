﻿import json
d = json.load(open(r".tmp/s14b/runs/s12_ch2/verify.json", encoding="utf-8"))
print(type(d), list(d)[:20])
def walk(o, depth=0, path=""):
    if depth > 2: return
    if isinstance(o, dict):
        for k,v in list(o.items())[:12]:
            print("  "*depth, path+"/"+str(k), type(v).__name__, (str(v)[:80].replace("\n"," ") if not isinstance(v,(dict,list)) else ""))
            walk(v, depth+1, path+"/"+str(k))
    elif isinstance(o, list) and o:
        print("  "*depth, path, "list len", len(o))
        walk(o[0], depth+1, path+"[0]")
walk(d)
