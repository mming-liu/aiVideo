# -*- coding: utf-8 -*-
"""S24: Closeout ch2 storyboard into 12 physically coherent shots (<=90s, <=12s/shot)."""
import copy
import json
import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
os.environ["OUTPUT_BASE"] = str(HERE / "output")
os.environ["STEP01_LOG_PATH"] = os.devnull
sys.path.insert(0, str(ROOT))

from step01_script_gen.plan_feasibility import check_event_contract  # noqa: E402
from step01_script_gen.timecode import (  # noqa: E402
    _compute_timecodes,
    active_shot_cap,
    shot_content_floor,
)
from step01_script_gen.validation import (  # noqa: E402
    _check_kf_time_window_alignment,
    _validate_script,
)

script = json.loads((HERE / "s24_parsed.json").read_text(encoding="utf-8"))
plan = json.loads((HERE / "candidate_plan.json").read_text(encoding="utf-8"))
raw_shots = copy.deepcopy(script["shots"])


def _merge_shots(
    group,
    *,
    new_dur,
    motion_segments,
    nar=None,
    beats=None,
    lines=None,
    location=None,
    scene=None,
    camera_movement=None,
    shot_type=None,
    ff_desc=None,
    lf_desc=None,
    ff_layout=None,
    lf_layout=None,
):
    """Merge contiguous shots, synchronizing location/camera/ff/lf/kfs/layouts/motion/refs."""
    first = copy.deepcopy(group[0])
    last = copy.deepcopy(group[-1])
    first["duration_sec"] = float(new_dur)
    if location is not None:
        first["location"] = location
    if scene is not None:
        first["scene"] = scene
    if camera_movement is not None:
        first["camera_movement"] = camera_movement
    if shot_type is not None:
        first["shot_type"] = shot_type
    first["ff_desc"] = ff_desc if ff_desc is not None else first["ff_desc"]
    first["lf_desc"] = lf_desc if lf_desc is not None else last["lf_desc"]
    first["frame_layouts"]["ff"] = copy.deepcopy(
        ff_layout if ff_layout is not None else first["frame_layouts"]["ff"]
    )
    first["frame_layouts"]["lf"] = copy.deepcopy(
        lf_layout if lf_layout is not None else last["frame_layouts"]["lf"]
    )
    if nar is not None:
        first["narration_segment"] = nar
        first["subtitle"] = nar

    m_parts = []
    new_kfs = []
    new_fl_kfs = []
    for seg_label, t0, t1, desc, stage, fl_kf in motion_segments:
        m_parts.append(f"{seg_label}：{desc}")
        mid = round((t0 + t1) / 2.0, 2)
        new_kfs.append({"desc": desc, "stage": stage, "t_sec": mid})
        new_fl_kfs.append(copy.deepcopy(fl_kf))
    first["motion_desc"] = "；".join(m_parts) + "。"
    first["keyframes"] = new_kfs
    first["frame_layouts"]["kfs"] = new_fl_kfs

    if beats is not None:
        first.setdefault("plan_refs", {})["beats"] = list(beats)
    else:
        b_all = []
        for s in group:
            for b in (s.get("plan_refs") or {}).get("beats") or []:
                if b not in b_all:
                    b_all.append(b)
        first.setdefault("plan_refs", {})["beats"] = b_all
    if lines is not None:
        first.setdefault("plan_refs", {})["lines"] = list(lines)
    else:
        l_all = []
        for s in group:
            for ln in (s.get("plan_refs") or {}).get("lines") or []:
                if ln not in l_all:
                    l_all.append(ln)
        first.setdefault("plan_refs", {})["lines"] = l_all
    return first


# Build 12 physically coherent shots (no indoor/outdoor teleport, no `静止` cut contradiction):
# 1: raw 1+2+3 (B1+B2+B3, D1+D2, indoor tavern) -> 11.125s (floor=11.125s)
s1 = _merge_shots(
    raw_shots[0:3],
    new_dur=11.125,
    nar="冯西辉道：四年前，你我四人奉命离开应天府，潜入这青州城。这才把杨旭扶持起来。",
    beats=[1, 2, 3],
    lines=[1, 2],
    camera_movement="缓推",
    motion_segments=[
        ("0-3秒", 0.0, 3.0, "门缝光柱斜切昏暗店内，四人围桌端坐，气氛压抑沉闷", "pre", raw_shots[0]["frame_layouts"]["kfs"][0]),
        ("3-7.5秒", 3.0, 7.5, "机位缓缓推进，冯西辉开口说话，眼神冷峻望向桌面，手掌轻按桌沿", "mid", raw_shots[1]["frame_layouts"]["kfs"][1]),
        ("7.5-11.125秒", 7.5, 11.125, "冯西辉顿住话头，手指微收，其余三人神情凝重听着", "post", raw_shots[2]["frame_layouts"]["kfs"][-1]),
    ],
)

# 2: raw 4 (B4, D3, indoor tavern) -> 8.75s
s2 = copy.deepcopy(raw_shots[3])
s2["duration_sec"] = 8.75

# 3: raw 5 (B5, D4, indoor tavern) -> 9.75s
s3 = copy.deepcopy(raw_shots[4])
s3["duration_sec"] = 9.75

# 4: raw 6 (B6, D5, indoor tavern) -> 6.0s
s4 = copy.deepcopy(raw_shots[5])
s4["duration_sec"] = 6.0

# 5: raw 7 (B7, D6, indoor tavern) -> 8.125s (floor=8.125s)
s5 = copy.deepcopy(raw_shots[6])
s5["duration_sec"] = 8.125

# 6: raw 8 (B8, D7, indoor tavern) -> 9.5s (fix missing kf segment [2])
s6 = copy.deepcopy(raw_shots[7])
s6["duration_sec"] = 9.5
if len(s6.get("keyframes") or []) == 3:
    s6["keyframes"].insert(
        2,
        {
            "desc": "安立桐身子前倾，嘴唇动了动没敢开口，只攥紧白手帕擦汗",
            "stage": "mid",
            "t_sec": 6.0,
        },
    )
    s6["frame_layouts"]["kfs"].insert(2, copy.deepcopy(s6["frame_layouts"]["kfs"][1]))

# 7: raw 9+10 (B9+B10+B11, D8, indoor tavern -> doorway silhouette) -> 8.375s
s7 = _merge_shots(
    raw_shots[8:10],
    new_dur=8.375,
    nar=raw_shots[8]["narration_segment"],
    beats=[9, 10, 11],
    lines=[8],
    camera_movement="环绕转摇镜",
    motion_segments=[
        ("0-3秒", 0.0, 3.0, "张十三冷笑驳斥，目光锐利盯向画右安立桐", "pre", raw_shots[8]["frame_layouts"]["kfs"][0]),
        ("3-6秒", 3.0, 6.0, "张十三语气凌厉逼问，安立桐脸色发白额头渗汗", "mid", raw_shots[8]["frame_layouts"]["kfs"][1]),
        ("6-8.375秒", 6.0, 8.375, "门外天光一暗出现人影，刘旭抬头看清来人，身子一震僵在椅上", "post", raw_shots[9]["frame_layouts"]["kfs"][-1]),
    ],
)

# 8: raw 11+12 (B12+B13+B14: doorway beggar -> parallel split-screen comparison with carriage corpse) -> 4.5s
s8 = _merge_shots(
    raw_shots[10:12],
    new_dur=4.5,
    nar="",
    beats=[12, 13, 14],
    lines=[],
    location="南阳河畔酒家门口（分屏并置后院马车）",
    scene="酒家门口与后院马车分屏对比",
    camera_movement="推拉切镜",
    shot_type="特写",
    ff_desc="门槛外叫化子一脸寒酸，破褐下摆如丝如缕，右手提着一串大小不一的鲜鱼，鱼尾轻摆",
    lf_desc="画面左右分屏并置：左屏为叫化子黝黑面容与挽袖结实小臂，右屏为后院马车帘缝白净杨旭尸体面容，五官一模一样，仅肤色与体格微差",
    motion_segments=[
        ("0-1.5秒", 0.0, 1.5, "门槛外叫化子破褐提鱼，鱼尾轻轻摆动，抬眼扫向店内", "pre", raw_shots[10]["frame_layouts"]["kfs"][0]),
        ("1.5-3.0秒", 1.5, 3.0, "推近叫化子面容并切出后院马车帘缝白布下杨旭尸体，两张脸并置，五官轮廓一模一样", "mid", raw_shots[11]["frame_layouts"]["kfs"][1]),
        ("3.0-4.5秒", 3.0, 4.5, "分屏对照叫化子挽袖露出的黝黑结实小臂与杨旭白净面容，差别微乎其微", "post", raw_shots[11]["frame_layouts"]["kfs"][-1]),
    ],
)

# 9: raw 13+14 (B15+B16+B17: beggar turns away from doorway -> pan indoors Feng points & Liu puts down knife exits) -> 4.0s
_s9_kf2_layout = copy.deepcopy(raw_shots[13]["frame_layouts"]["kfs"][1])
for _c in _s9_kf2_layout:
    if _c.get("name") == "冯西辉":
        _c["states"] = ["皱眉摆手"]
    if _c.get("name") == "刘旭":
        _c["on_screen"] = True
        _c["position"] = "画右门旁"
        _c["pose"] = "转身迈步走向店门"
        _c["gaze_target"] = "画右"
        _c["props"] = []
        _c["support"] = {"id": "door_1", "kind": "门槛", "surface": "门槛内地面"}
        _c["states"] = ["空手", "神情讪讪"]
_s9_lf_layout = copy.deepcopy(raw_shots[13]["frame_layouts"]["lf"])
for _c in _s9_lf_layout:
    if _c.get("name") == "刘旭":
        _c["props"] = []
        _c["states"] = ["空手", "出门"]
s9 = _merge_shots(
    raw_shots[12:14],
    new_dur=4.0,
    nar="",
    beats=[15, 16, 17],
    lines=[],
    location="南阳河畔酒家",
    scene="南阳河畔酒家门口转店内",
    camera_movement="摇镜",
    shot_type="中景",
    ff_desc="门槛外叫化子察觉店内目光怪异，笑意一滞，眼神警觉扫过屋内四人，手提鲜鱼欲转身",
    lf_desc="酒家门内桌旁，冯西辉皱眉摆手，刘旭已放下刀跨出店门背影消隐于门框外",
    lf_layout=_s9_lf_layout,
    motion_segments=[
        ("0-1.3秒", 0.0, 1.3, "门槛外叫化子察觉店内目光怪异，警觉扫视后提鱼转身离门", "pre", raw_shots[12]["frame_layouts"]["kfs"][0]),
        ("1.3-2.6秒", 1.3, 2.6, "镜头从门口摇回室内桌旁，冯西辉沉脸指门外，刘旭点头返身提刀", "mid", raw_shots[13]["frame_layouts"]["kfs"][1]),
        ("2.6-4.0秒", 2.6, 4.0, "冯西辉皱眉摆手制止，刘旭讪讪放下刀转身迈向店门走出门槛", "post", _s9_kf2_layout),
    ],
)

# 10: raw 15 ALONE (B18: outdoor riverbank path tracking) -> 3.5s
s10 = _merge_shots(
    [raw_shots[14]],
    new_dur=3.5,
    nar="",
    beats=[18],
    lines=[],
    location="南阳河畔小径",
    scene="南阳河畔柳树小径",
    camera_movement="跟拍",
    shot_type="全景",
    motion_segments=[
        ("0-2.0秒", 0.0, 2.0, "南阳河畔小径上，提鱼的叫化子在前行走，刘旭远远缀在身后尾随", "pre", raw_shots[14]["frame_layouts"]["kfs"][0]),
        ("2.0-3.5秒", 2.0, 3.5, "镜头跟拍，叫化子与刘旭一前一后拐过岸边一株柳树", "post", raw_shots[14]["frame_layouts"]["kfs"][-1]),
    ],
)

# 11: raw 16 (B19, D9, indoor tavern) -> 7.875s (fix ellipsis)
s11 = copy.deepcopy(raw_shots[15])
s11["duration_sec"] = 7.875
for _fld in ("narration_segment", "subtitle"):
    if isinstance(s11.get(_fld), str):
        s11[_fld] = s11[_fld].replace("莫非…莫非", "莫非……莫非")

# 12: raw 17 (B20, D10, indoor tavern) -> 7.125s (insert missing kf segment [3])
s12 = copy.deepcopy(raw_shots[16])
s12["duration_sec"] = 7.125
if len(s12.get("keyframes") or []) == 3:
    s12["keyframes"].append(
        {"desc": "狭长略弯的绣春刀刀身寒光一闪，冯西辉指肚轻拭刀锋", "stage": "post", "t_sec": 6.5}
    )
    s12["frame_layouts"]["kfs"].append(copy.deepcopy(s12["frame_layouts"]["kfs"][-1]))

closed = [s1, s2, s3, s4, s5, s6, s7, s8, s9, s10, s11, s12]
for i, sh in enumerate(closed, 1):
    sh["index"] = i
script["shots"] = closed
_compute_timecodes(script, allow_split=False)

cap = float(active_shot_cap())
total_dur = sum(float(s.get("duration_sec") or 0) for s in script["shots"])
floor_bad = [
    (s["index"], s["duration_sec"], shot_content_floor(s))
    for s in script["shots"]
    if float(s.get("duration_sec") or 0) + 1e-6 < shot_content_floor(s)
]
cap_bad = [
    (s["index"], s["duration_sec"], cap)
    for s in script["shots"]
    if float(s.get("duration_sec") or 0) > cap + 1e-6
]
ec_ok, ec_probs, ec_strict = check_event_contract(script, plan)
kf_warns = _check_kf_time_window_alignment(script["shots"], hook=script.get("hook"))
_validate_script(script)

all_beats = [b for s in script["shots"] for b in (s.get("plan_refs") or {}).get("beats") or []]
all_lines = [ln for s in script["shots"] for ln in (s.get("plan_refs") or {}).get("lines") or []]
all_nar = "\n".join(str(s.get("narration_segment") or "") for s in script["shots"])
missing_voices = [v for v in (plan.get("dialogue_lines") or []) if v not in all_nar]

report = {
    "shots": len(script["shots"]),
    "total_dur": round(total_dur, 3),
    "in_band_60_90": 60.0 <= total_dur <= 90.0,
    "cap": cap,
    "cap_bad": cap_bad,
    "floor_bad": floor_bad,
    "event_contract": {"ok": ec_ok, "problems": ec_probs, "strict": ec_strict},
    "kf_time_window_warns": kf_warns,
    "beats_covered": all_beats,
    "beats_complete": sorted(set(all_beats)) == list(range(1, 21)),
    "lines_covered": all_lines,
    "lines_complete": sorted(set(all_lines)) == list(range(1, 11)),
    "missing_voices": missing_voices,
    "per_shot": [
        {
            "index": s["index"],
            "dur": s["duration_sec"],
            "floor": shot_content_floor(s),
            "location": s.get("location"),
            "camera": s.get("camera_movement"),
            "beats": (s.get("plan_refs") or {}).get("beats"),
            "lines": (s.get("plan_refs") or {}).get("lines"),
            "kfs": len(s.get("keyframes") or []),
            "fl_kfs": len((s.get("frame_layouts") or {}).get("kfs") or []),
        }
        for s in script["shots"]
    ],
}

(HERE / "s24_final_storyboard.json").write_text(
    json.dumps(script, ensure_ascii=False, indent=1), encoding="utf-8"
)
(HERE / "s24_closeout_report.json").write_text(
    json.dumps(report, ensure_ascii=False, indent=1), encoding="utf-8"
)
print(json.dumps(report, ensure_ascii=False, indent=1))
