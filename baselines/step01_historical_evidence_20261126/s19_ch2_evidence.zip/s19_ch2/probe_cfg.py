﻿import json,sys
sys.path.insert(0, ".tmp/s19_ch2")
import common, shared.config
from _text_gen.config import TextGenCfg
from _text_gen.agent_plan_provider import is_subscription_endpoint
print("PROVIDER", TextGenCfg.PROVIDER)
print("MODEL", TextGenCfg.default_text_model())
print("BASE", TextGenCfg.AGENT_PLAN_TEXT_BASE_URL)
ep = TextGenCfg.AGENT_PLAN_TEXT_BASE_URL.rstrip("/") + "/chat/completions"
print("EP", ep, "sub", is_subscription_endpoint(ep))
print("sub base", is_subscription_endpoint(TextGenCfg.AGENT_PLAN_TEXT_BASE_URL))
