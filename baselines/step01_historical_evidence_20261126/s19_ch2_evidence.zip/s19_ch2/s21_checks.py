# -*- coding: utf-8 -*-
"""S21/S22：候选的投影回读、计划验收、生成前检查与执行契约核对（全离线）."""
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import common  # noqa: E402

from shared import presentation_contract as pc  # noqa: E402
from step01_script_gen import lightweight_plan as lw  # noqa: E402
from step01_script_gen.plan_feasibility import (  # noqa: E402
    check_plan_before_generation, evaluate_plan, fact_carrier, plan_voice_entries,
    voice_entry_costs)
from step01_script_gen.outline import plan_acceptance_problems  # noqa: E402

OUT = common.HERE / "s21_checks.json"


def main():
    common.assert_frozen()
    base = common.load_plan()
    novel = common.load_novel()
    cand = common.read_json(common.HERE / "candidate_plan.json")
    view, probs = pc.view_from_plan(cand)
    roundtrip = pc.plan_from_view(view) if view else None
    rep = evaluate_plan(cand, novel_text=novel)
    contract = check_plan_before_generation(cand, chapter_dir=None, novel_text=novel)
    accept = plan_acceptance_problems(cand, novel_text=novel)
    costs = voice_entry_costs(cand)
    entries = plan_voice_entries(cand)
    from step01_script_gen.prompts import render_execution_contract
    from step01_script_gen.plan_feasibility import plan_identity, fact_evidence_text
    block = render_execution_contract(cand)

    result = {
        "input": {"plan_sha256": common.sha256_file(common.FROZEN["plan"]),
                  "candidate_sha256": common.sha256_text(json.dumps(cand, ensure_ascii=False,
                                                                   sort_keys=True))},
        "projection": {"ok": not probs, "problems": probs,
                       "roundtrip_fixed_point": roundtrip == cand},
        "acceptance": {"count": len(accept), "codes": [p.get("code") for p in accept]},
        "evaluate": {"verdict": rep["verdict"], "dialogue_sec": rep["dialogue_sec"],
                     "narration_sec": rep.get("narration_sec"),
                     "lower_bound_sec": rep["lower_bound_sec"],
                     "budget": rep["budget"], "reasons": rep["reasons"],
                     "beats": rep.get("beats_floor_basis")},
        "before_generation": {"ok": contract.get("verdict") == "feasible",
                              "verdict": contract.get("verdict")},
        "voices": [{"id": c["id"], "kind": c["kind"], "est_sec": c["est_sec"],
                    "body_sec": c["body_sec"], "representable": c["representable"],
                    "beats": c["beats"], "text": c["text"]} for c in costs],
        "voice_units": cand.get("voice_units"),
        "facts": [{"uid": "f%02d" % (i + 1), "carrier": fact_carrier(f),
                   "claim": f.split("｜原文证据")[0][:80]}
                  for i, f in enumerate(cand.get("required_facts") or [])],
        "identity": {"plan_id": plan_identity(cand),
                     "lightweight": cand.get("lightweight_plan"),
                     "coherence": cand.get("plan_coherence_version"),
                     "time_budget": cand.get("time_budget")},
        "contract_block": {"chars": len(block), "has_all_voices":
                           all(c["text"] in block for c in costs),
                           "has_timing": "声音时长" in block or "估时" in block,
                           "tail": block[-400:]},
        "counts": {"voices": len(entries),
                   "dialogue": sum(1 for e in entries if e["kind"] == "dialogue"),
                   "narration": sum(1 for e in entries if e["kind"] == "narration"),
                   "beats": len(cand.get("shot_beats") or []),
                   "facts": len(cand.get("required_facts") or [])},
    }
    common.write_json(OUT, result)
    print(json.dumps({k: result[k] for k in ("projection", "acceptance", "evaluate",
                                             "before_generation", "counts", "identity")},
                     ensure_ascii=False, indent=1)[:2600])
    print("--- voices")
    for c in costs:
        print("%s %-8s est=%5.2f body=%5.2f rep=%s beats=%s %s" % (
            c["id"], c["kind"], c["est_sec"], c["body_sec"], c["representable"],
            c["beats"], c["text"][:42]))
    print("--- contract tail")
    print(result["contract_block"]["tail"])


if __name__ == "__main__":
    main()
