# -*- coding: utf-8 -*-
"""S19 离线运行公共件：导入前隔离路径、阻断外部网络、装载冻结输入.

只在 `.tmp/s19_ch2` 的实验脚本里使用；生产代码不依赖本文件。
"""
import hashlib
import json
import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
ISOLATED_OUTPUT = HERE / "output"

# ---- 1. 导入生产模块之前完成路径隔离（章节读取 / 日志初始化都走 OUTPUT_BASE）----
os.environ["OUTPUT_BASE"] = str(ISOLATED_OUTPUT)
os.environ["STEP01_LOG_PATH"] = os.devnull
os.environ.setdefault("TEXT_TRANSPORT_RETRIES", "0")
os.environ.setdefault("TEXT_TRANSPORT_CONNECT_RETRIES", "0")
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))


# ---- 2. 导入前阻断外部网络（任何 connect 都抛错，而不是只靠"不调用"）----
class NetworkBlocked(RuntimeError):
    pass


def _blocked(*_a, **_k):
    raise NetworkBlocked("offline run: external network access is blocked")


def block_network() -> None:
    import socket
    socket.socket.connect = _blocked          # type: ignore[assignment]
    socket.socket.connect_ex = _blocked       # type: ignore[assignment]
    socket.create_connection = _blocked       # type: ignore[assignment]


block_network()

FROZEN = {
    "plan": ROOT / ".tmp/s14b/runs/s12_ch2/rebound_plan.json",
    "plan_sha256": "fb8ac9f7302c48240cb5b740bdbf58f6309ebced6157d156166cc1fec030adec",
    "chapter_text": HERE / "chapter2_text.txt",
    "chapter_sha256": "750dbcca39a0cac5114c78d1e5ca681dc454f1274fadc1563764c763bd8d403e",
    "ch1_storyboard": ROOT / ".tmp/s14b/runs/s18_final/storyboard.json",
    "ch1_candidate": ROOT / ".tmp/s14b/runs/s13c_ch1/candidate_plan.json",
    "novel": ROOT / "锦衣夜行_77119小说.txt",
    "protect": ROOT / ".tmp/s14b/protect_before.json",
    "ledger_ch1": ROOT / ".tmp/s14b/quota_ch1.json",
    "ledger_ch2": ROOT / ".tmp/s14b/quota_ch2.json",
    "incident_log": ROOT / "output/锦衣夜行/part_01_杀青州/chapter_001/step01.log",
}


def sha256_file(path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def sha256_text(text: str) -> str:
    return hashlib.sha256(str(text or "").encode("utf-8")).hexdigest()


def load_plan() -> dict:
    return json.loads(FROZEN["plan"].read_text(encoding="utf-8"))


def load_novel() -> str:
    return FROZEN["chapter_text"].read_text(encoding="utf-8")


def assert_frozen() -> dict:
    """冻结身份核对：任何一项不符直接失败（不按"最新文件"选样本）."""
    plan_sha = sha256_file(FROZEN["plan"])
    ch_sha = sha256_text(load_novel())
    if plan_sha != FROZEN["plan_sha256"]:
        raise SystemExit("FROZEN_INPUT_MISMATCH plan %s" % plan_sha)
    if ch_sha != FROZEN["chapter_sha256"]:
        raise SystemExit("FROZEN_INPUT_MISMATCH chapter %s" % ch_sha)
    return {"plan_sha256": plan_sha, "chapter_sha256": ch_sha}


def write_json(path, payload) -> None:
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(payload, ensure_ascii=False, indent=1) + "\n", encoding="utf-8")


def read_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))
