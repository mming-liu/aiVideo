# -*- coding: utf-8 -*-
"""S19：冻结本包输入、有效配置、保护范围与运行边界（只读 + 写 .tmp/s19_ch2）."""
import json
import subprocess
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import common  # noqa: E402  （导入即完成路径隔离 + 网络阻断）

OUT = common.HERE / "s19_freeze.json"
REPORT = common.HERE / "s19_protection_check.json"


def _git(*args):
    try:
        return subprocess.run(["git", *args], cwd=str(common.ROOT), capture_output=True,
                              text=True, encoding="utf-8", check=False).stdout.strip()
    except Exception as exc:  # noqa: BLE001
        return "git_error:%s" % exc


def _effective_config():
    import shared.config  # noqa: F401  （load_dotenv：进程环境优先于文件）
    from _text_gen.config import TextGenCfg
    from _text_gen.agent_plan_provider import is_subscription_endpoint
    base = str(TextGenCfg.AGENT_PLAN_TEXT_BASE_URL or "")
    endpoint = base.rstrip("/") + "/chat/completions" if base else ""
    audit_provider = __import__("os").getenv("AUDIT_TEXT_PROVIDER", "").strip()
    repair_provider = __import__("os").getenv("REPAIR_TEXT_PROVIDER", "").strip()
    return {
        "TEXT_PROVIDER": TextGenCfg.PROVIDER,
        "AGENT_PLAN_TEXT_MODEL": TextGenCfg.default_text_model(),
        "AGENT_PLAN_TEXT_BASE_URL": base,
        "endpoint": endpoint,
        "is_subscription_endpoint": bool(base) and is_subscription_endpoint(base),
        "AUDIT_TEXT_PROVIDER": audit_provider,
        "AUDIT_TEXT_MODEL": __import__("os").getenv("AUDIT_TEXT_MODEL", "").strip(),
        "REPAIR_TEXT_PROVIDER": repair_provider,
        "REPAIR_TEXT_MODEL": __import__("os").getenv("REPAIR_TEXT_MODEL", "").strip(),
        "AUDIT_TIMEOUT_SEC": __import__("os").getenv("AUDIT_TIMEOUT_SEC", "").strip(),
        "STEP01_PLAN_MODE": __import__("os").getenv("STEP01_PLAN_MODE", "").strip() or None,
        "STEP01_PRESENTATION_MODE": __import__("os").getenv("STEP01_PRESENTATION_MODE", "").strip() or None,
        "VIDEO_REFERENCE_MODE": __import__("os").getenv("VIDEO_REFERENCE_MODE", "").strip(),
        "AUDIT_TEXT_PROVIDER_matches_text": audit_provider in ("", TextGenCfg.PROVIDER),
        "REPAIR_TEXT_PROVIDER_matches_text": repair_provider in ("", TextGenCfg.PROVIDER),
        "source": "进程环境 + 命令行（本脚本无环境覆盖）+ .env.content/.env.keys 叠加",
    }


def _limits():
    from step01_script_gen.plan_feasibility import budget_band
    from step01_script_gen.timecode import active_shot_cap, MIN_SHOT_DURATION, MAX_SHOT_DURATION
    from step01_script_gen import lightweight_voice_repair as vr
    bmin, bmax = budget_band()
    return {
        "duration_band_sec": [bmin, bmax],
        "shot_cap_sec": float(active_shot_cap()),
        "shot_min_sec": float(MIN_SHOT_DURATION),
        "shot_max_project_cap_sec": float(MAX_SHOT_DURATION),
        "voice_max_lines_default": int(vr.MAX_LINES),
        "voice_max_lines_effective": int(vr.line_limit()),
        "voice_max_han": int(vr.MAX_HAN),
        "voice_max_line_han": int(vr.MAX_LINE_HAN),
        "voice_target_sec": int(vr.TARGET_SEC),
        "replacement_sec": int(vr.REPLACEMENT_SEC),
    }


def _ledgers():
    out = {}
    for key in ("ch1", "ch2"):
        p = common.FROZEN["ledger_%s" % key]
        data = common.read_json(p) if p.exists() else {}
        chapters = data.get("chapters") if isinstance(data.get("chapters"), dict) else data
        entry = chapters.get("2") or chapters.get(2) or chapters
        out[key] = {"path": str(p.relative_to(common.ROOT)),
                    "used": entry.get("used"), "max": entry.get("max"),
                    "over_cap": entry.get("over_cap"),
                    "attempts": len(entry.get("attempts") or [])}
    return out


def _protection():
    manifest = common.read_json(common.FROZEN["protect"])
    extra = {
        str(common.FROZEN["incident_log"].relative_to(common.ROOT)): None,
        str(common.FROZEN["ledger_ch1"].relative_to(common.ROOT)): None,
        str(common.FROZEN["ledger_ch2"].relative_to(common.ROOT)): None,
    }
    rows, missing, changed, unverified = {}, [], [], []
    for rel, expected in list(manifest.items()) + list(extra.items()):
        p = common.ROOT / rel
        if not p.exists():
            missing.append(rel)
            rows[rel] = {"exists": False, "expected": expected, "status": "missing"}
            continue
        now = common.sha256_file(p)
        if expected is None:
            unverified.append(rel)
            rows[rel] = {"exists": True, "expected": None, "now": now,
                         "equal": None, "status": "no_pre_task_baseline"}
        else:
            ok = expected == now
            rows[rel] = {"exists": True, "expected": expected, "now": now,
                         "equal": ok, "status": "matched" if ok else "changed"}
            if not ok:
                changed.append(rel)
    return {"count": len(rows), "baselined_count": len(manifest),
            "missing": missing, "changed": changed,
            "unverified_no_baseline": unverified, "rows": rows}


def main():
    frozen = common.assert_frozen()
    plan = common.load_plan()
    protection = _protection()
    payload = {
        "package": "S19-S25 chapter2 completion",
        "generated_at": None,
        "code": {
            "head": _git("rev-parse", "HEAD"),
            "branch": _git("branch", "--show-current"),
            "dirty_tracked": [x for x in _git("status", "--porcelain=v1").splitlines()
                              if x[:2].strip()],
        },
        "inputs": {
            "ch2_rebound_plan": {"path": str(common.FROZEN["plan"].relative_to(common.ROOT)),
                                 "sha256": frozen["plan_sha256"],
                                 "facts": len(plan.get("required_facts") or []),
                                 "voices": len(plan.get("voice_units") or []),
                                 "beats": len(plan.get("shot_beats") or []),
                                 "time_budget": plan.get("time_budget")},
            "chapter2_text": {"path": str(common.FROZEN["chapter_text"].relative_to(common.ROOT)),
                              "sha256": frozen["chapter_sha256"]},
            "novel_file": {"path": common.FROZEN["novel"].name,
                           "sha256": common.sha256_file(common.FROZEN["novel"])},
            "ch1_final_storyboard": {"path": str(common.FROZEN["ch1_storyboard"].relative_to(common.ROOT)),
                                     "sha256": common.sha256_file(common.FROZEN["ch1_storyboard"])
                                     if common.FROZEN["ch1_storyboard"].exists() else None},
            "ch1_candidate_plan": {"path": str(common.FROZEN["ch1_candidate"].relative_to(common.ROOT)),
                                   "sha256": common.sha256_file(common.FROZEN["ch1_candidate"])
                                   if common.FROZEN["ch1_candidate"].exists() else None},
        },
        "effective_config": _effective_config(),
        "limits": _limits(),
        "ledgers": _ledgers(),
        "protection": {k: protection[k] for k in ("count", "missing", "changed")},
        "run_boundary": {
            "offline": True,
            "network": "socket.connect/create_connection 在导入业务模块前已被替换为抛错",
            "output_base": str(common.ISOLATED_OUTPUT),
            "real_calls_allowed": False,
            "gate": "S23/S24 需用户明确恢复第二章真实调用；第一章不再调用",
            "formal_artifacts": "只读；不写正式目录，不覆盖正式产物",
        },
    }
    common.write_json(OUT, payload)
    common.write_json(REPORT, protection)
    print(json.dumps({"frozen": str(OUT), "protection": {k: protection[k]
                                                         for k in ("count", "missing", "changed")},
                      "plan_sha256": frozen["plan_sha256"],
                      "config_ok": payload["effective_config"]["is_subscription_endpoint"],
                      "ledgers": payload["ledgers"]}, ensure_ascii=False, indent=1))


if __name__ == "__main__":
    main()
