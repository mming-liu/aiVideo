# -*- coding: utf-8 -*-
"""S23: Guarded independent verification via VerificationController (with source_preservation)."""
import json
import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))

EXPECTED_ENDPOINT = "https://opencode.ai/inference/go/openai/v1/chat/completions"
CHAPTER_LEDGER = ROOT / ".tmp" / "s14b" / "quota_ch2.json"
BATCH_LEDGER = HERE / "quota_s23_ctrl_ch2.json"
PLAN_PATH = HERE / "candidate_plan.json"
NOVEL_PATH = HERE / "chapter2_text.txt"
OUT_PATH = HERE / "s23_verify.json"

from _text_gen import chapter_quota as lg  # noqa: E402


def _json(p: Path):
    return json.loads(p.read_text(encoding="utf-8"))


def main():
    if BATCH_LEDGER.exists():
        raise SystemExit(f"batch ledger exists: {BATCH_LEDGER}")
    max_posts = 6
    try:
        rid = lg.reserve_batch(CHAPTER_LEDGER, BATCH_LEDGER, max_posts, tag=BATCH_LEDGER.name)
    except lg.QuotaError as exc:
        raise SystemExit(f"chapter quota reservation refused before send: {exc}")

    os.environ["STEP01_CHAPTER_QUOTA_FILE"] = str(CHAPTER_LEDGER)
    os.environ["TEXT_SEND_QUOTA_FILE"] = str(BATCH_LEDGER)
    os.environ["OUTPUT_BASE"] = str(HERE / "output")
    os.environ["STEP01_LOG_PATH"] = str(HERE / "s23_step01.log")
    os.environ.pop("STEP01_READ_ONLY", None)

    out = {"success": False, "error": "", "status": "", "record": None, "verification_problems": []}
    try:
        import shared.config  # noqa: F401
        from _text_gen.agent_plan_provider import chat_completions_url, is_subscription_endpoint
        from _text_gen.config import TextGenCfg

        base = str(os.environ.get("AGENT_PLAN_TEXT_BASE_URL") or "")
        if (
            TextGenCfg.PROVIDER != "agent_plan"
            or not base
            or chat_completions_url(base) != EXPECTED_ENDPOINT
            or not is_subscription_endpoint(base)
        ):
            raise SystemExit(f"channel preflight failed: provider={TextGenCfg.PROVIDER} base={base}")

        from shared import presentation_contract as pc
        from shared.content_verification import (
            DEFAULT_RULE_VERSION,
            VerificationController,
            plan_digest_of,
            record_protocol_problems,
            record_shape_problems,
            verification_problems,
        )
        from step01_script_gen import content_verify as cv

        plan = _json(PLAN_PATH)
        novel = NOVEL_PATH.read_text(encoding="utf-8")
        view, bad = pc.view_from_plan(plan)
        out["view_problems"] = bad
        if bad:
            raise SystemExit(f"view unreadable: {bad}")
        digest = plan_digest_of(plan)
        ident = cv.novel_identity(novel)

        def _verify(v, d):
            return cv.verify_view_with_service(
                v,
                d,
                novel_text=novel,
                novel_digest=ident["digest"],
                novel_version=str(ident.get("version") or ""),
                source_references=True,
            )

        def _validate_rec(record, v, d):
            return record_protocol_problems(
                record,
                v,
                plan_digest=d,
                novel_text=novel,
                novel_digest=ident["digest"],
            )

        def _repair_rec(v, d, failure, previous):
            return cv.verify_view_with_service(
                v,
                d,
                novel_text=novel,
                novel_digest=ident["digest"],
                novel_version=str(ident.get("version") or ""),
                source_references=True,
                correction={
                    "problems": failure.get("problems", []),
                    "error": failure.get("error", ""),
                    "previous_response": previous,
                },
            )

        ctl = VerificationController(
            verify=_verify,
            require_coherence=True,
            validate_record=_validate_rec,
            repair=_repair_rec,
            rule_version=DEFAULT_RULE_VERSION,
            novel_digest=ident["digest"],
            max_verifications=2,
            log=print,
        )
        rec = ctl.record_for(view, digest)
        out["record"] = rec
        out["status"] = str((rec or {}).get("status") or "")
        out["plan_digest"] = digest
        out["novel_digest"] = ident["digest"]
        out["controller_used"] = ctl.used
        vprobs = verification_problems(
            rec,
            view,
            plan_digest=digest,
            plan=plan,
            novel_digest=ident["digest"],
            novel_text=novel,
        )
        out["shape_problems"] = record_shape_problems(rec)
        out["verification_problems"] = vprobs
        # Only succeed if status=='ok' AND zero verification_problems (incl. source_preservation)
        out["success"] = (out["status"] == "ok" and not vprobs)
        if not out["success"]:
            out["error"] = f"verification incomplete: status={out['status']} problems={len(vprobs)}"
    except BaseException as exc:  # noqa: BLE001
        out["error"] = f"{type(exc).__name__}: {str(exc)[:500]}"
    finally:
        st = lg.settle_batch(CHAPTER_LEDGER, rid, BATCH_LEDGER)
        out["settle"] = st.get("status")
        out["chapter_after"] = st.get("chapter_after")
        if st.get("status") == "settled":
            out["batch_used"] = st.get("spent")
        OUT_PATH.write_text(json.dumps(out, ensure_ascii=False, indent=1), encoding="utf-8")
    print(
        json.dumps(
            {
                k: out.get(k)
                for k in (
                    "success",
                    "status",
                    "error",
                    "batch_used",
                    "chapter_after",
                    "verification_problems",
                )
            },
            ensure_ascii=False,
        )
    )
    if not out["success"]:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
