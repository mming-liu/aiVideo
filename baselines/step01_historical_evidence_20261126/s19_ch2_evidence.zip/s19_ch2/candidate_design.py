# -*- coding: utf-8 -*-
"""S21：第二章 10 条声音的完整重分配候选（离线；只写 .tmp/s19_ch2）.

设计口径（S20 义务表的落地）：
- 12 条事实**全部保留**（主张/证据/父子谱系逐字节不动）；
- 10 条声音，全部逐字取自原文；说话人按原文引语归属；
- 无法由声音承载的画面事实（叫化子装扮/提鱼、五官相同、细微不同、察觉离开、
  跟踪命令）由节拍画面承载；
- 只合并、不新增语义：过渡对白（刘旭的猜测、安立桐提议如实说明）压缩为可观察反应，
  记录在 S20 的残余里。
"""
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import common  # noqa: E402

from shared import presentation_contract as pc  # noqa: E402
from step01_script_gen.lightweight_plan import compile_reallocated_plan  # noqa: E402

# ---- 10 条声音（逐字原文；只补句末句号，归一化后仍是原文子串）----
VOICES = [
    ("d01", "冯西辉", "四年前，你我四人奉命离开应天府，潜入这青州城。"),
    ("d02", "冯西辉", "这才把杨旭扶持起来。"),
    ("d03", "冯西辉", "上个月，本官刚刚给佥事大人递了消息，说杨旭已成为齐王心腹。"),
    ("d04", "冯西辉", "杨旭让人宰了，消息一旦传到佥事大人耳中，我们会是什么下场可想而知。"),
    ("d05", "张十三", "我们行事如此隐秘，怎么可能被人察觉？"),
    ("d06", "张十三", "可若是齐王下的手，他需要用行刺的手段？他会只杀杨旭？"),
    ("d07", "张十三", "我便抹去了船上的痕迹，用车子把他载来此地，消息此刻还未张扬开来。"),
    ("d08", "张十三", "大人的全部希望都葬送在咱们手里，你还指望大人会饶恕你吗？"),
    ("d09", "安立桐", "啊！我明白了，大人，莫非……莫非你想用这乞丐鱼目混珠？"),
    ("d10", "冯西辉", "绣春刀啊绣春刀，要到几时你的威风才能重现人间？"),
]

# ---- 20 条节拍（事件归属按冻结的 5 个事件；画面正文只写可观察内容）----
BEATS = [
    (1, "青州府外南阳河畔，酒家门前细竿光秃，门板只留一道缝；店内昏暗，张十三背门而坐，"
        "左首皂衣大汉冯西辉，右首团花员外衫的胖子安立桐，对面店主刘旭青布直掇，四人围桌，"
        "脸色阴沉，无人开口。",
     "交代地点、四人与压抑气氛",
     "青州府外南阳河畔，有一户酒家。这家店既卖酒，也卖茶。", None),
    (1, "冯西辉嘴唇微动，丝丝冒凉气，幽幽开口，目光落在桌面。",
     "交代四人四年前奉命离开应天府、潜入青州城",
     "四年前，你我四人奉命离开应天府，潜入这青州城，足足耗费了四年的时间，"
     "把佥事大人能够动用的全部财力、物力和人脉都用上了，这才把杨旭扶持起来。", "d01"),
    (1, "冯西辉抬眼扫过三人，手指在膝上收紧。",
     "交代杨旭是四人耗费四年扶持起来的",
     "四年前，你我四人奉命离开应天府，潜入这青州城，足足耗费了四年的时间，"
     "把佥事大人能够动用的全部财力、物力和人脉都用上了，这才把杨旭扶持起来。", "d02"),
    (2, "冯西辉的目光转向安立桐，声音更低，带着寒气。",
     "交代上月刚向佥事大人报告杨旭已成为齐王心腹",
     "上个月，本官刚刚给佥事大人递了消息，说杨旭已成为齐王心腹，"
     "大人可以开始进行下一步的行动了。", "d03"),
    (2, "冯西辉狠狠一捶桌子，茶杯一齐跳起，茶水溅出；窗纸外，后院马车帘缝里露出"
        "一具盖着白布的尸体，白布下透出人形轮廓。",
     "交代杨旭被杀，消息传出去四人都没有好下场",
     "冯检校狠狠一捶桌子，茶杯一齐跳了起来，冯检校这才恨声道：“杨旭让人宰了，"
     "消息一旦传到佥事大人耳中，我们会是什么下场可想而知。”", "d04"),
    (2, "张十三一声冷笑，眼皮一挑，毫不客气地斜睨刘旭；刘旭喘着粗气，满脸惊恐。",
     "张十三否认身份暴露的可能",
     "张十三一声冷笑，对这位年长他近一倍的同僚毫不客气地训斥道：“你是人头猪脑么！"
     "我们行事如此隐秘，怎么可能被人察觉？”", "d05"),
    (2, "张十三身体微倾，语速放慢，眼神冷峻，屈指在桌面上点了两下。",
     "排除齐王用行刺手段杀人的可能",
     "退一步说，如果我们真的暴露了身份，谁会对我们不利呢？唯有齐王，"
     "可若是齐王下的手，他需要用行刺的手段？他会只杀杨旭？", "d06"),
    (3, "安立桐脸色苍白，身子前倾，嘴唇动了动却没敢开口；张十三放下茶碗。",
     "张十三交代已抹去船上痕迹、载尸来此、消息尚未张扬",
     "杨文轩一死，我便抹去了船上的痕迹，用车子把他载来此地，消息此刻还未张扬开来，"
     "我连城都不进。", "d07"),
    (3, "张十三又是一声冷笑，目光扫过安立桐，安立桐的额头渗出冷汗。",
     "指出罗大人不会饶恕，大人的希望已葬送",
     "吃的灯草灰，放的轻巧屁！罗大人几时这般心慈面软过了，应天那边现在的情形你又不是不知道，"
     "我锦衣卫现在处境何等艰难，想要翻身，依赖的就是咱们了。四年前，大人还能给咱们提供"
     "一些帮助，帮咱们扶持一个杨文轩出来，现在，大人已不可能再给予我们任何帮助了，"
     "大人的全部希望都葬送在咱们手里，你还指望大人会饶恕你吗？", "d08"),
    (4, "门外天光一暗，一个蓬头垢面、披着破褐的身影担着鱼篓，站到门槛外。",
     "引入门外来客",
     "就在这时，门外有人喊道：“店家，在下捕了几尾鲜鱼，不知店家这里收吗，在下的价钱很公道，"
     "比起鱼铺子里来可要便宜多了。”", None),
    (4, "刘旭正心烦，头也不抬地挥手驱赶；抬眼看清来人，整个身子一震，僵在椅上。",
     "刘旭看清来人后僵住",
     "刘掌柜正在心烦意乱之中，挥手便嚷……待他看清店外那人模样，整个身子顿时一震，"
     "就像遭了雷击似的僵在那儿不动了。", None),
    (4, "冯西辉、张十三、安立桐同时扭头望向门口；门外叫化子一脸寒酸，破褐下摆如丝如缕，"
        "手里提着一串大小不一的鱼，柳枝穿着鱼鳃，鱼尾还在轻轻摆动。",
     "交代叫化子装扮与手提一串鲜鱼，四人震惊",
     "居然一副叫化子装扮，活生生地站在店门口，手里提着一串大小不一的鱼，"
     "用柳枝穿着鱼鳃，看起来那都是刚捕来的鲜鱼，鱼尾偶尔还会有气无力地摆动几下。", None),
    (4, "镜头推近叫化子的脸；切后院马车，车帘缝隙里露出杨旭尸体的脸——两张脸并置，"
        "五官轮廓一模一样。",
     "交代来人与死去的杨旭五官相貌一般无二",
     "这个人虽是一身寒酸，可是五官相貌却与杨旭一般无二……要不是杨旭的尸体就在后面"
     "车子里，咱们几个刚刚还亲自验看过的。", None),
    (4, "四人用挑剔的目光上下审视：叫化子挽起的袖口露出结实小臂，肤色黝黑；"
        "与杨旭白净的面容并置，差别微乎其微。",
     "交代细微不同：更结实、肤色更黑，区别微乎其微",
     "但是此人比杨旭结实一些，肤色也要比杨旭黑的多……发现二人的区别实在是微乎其微。", None),
    (5, "叫化子察觉店内目光怪异，笑意一滞，眼神警觉地扫过四人，打个哈哈，"
        "弯腰提鱼，转身离开门槛。",
     "叫化子察觉异样，提高警觉后提鱼离开",
     "此时察觉情形有异，立即提高了他的警觉，他打个哈哈道……说罢提了鱼就走。", None),
    (5, "冯西辉沉着脸转向刘旭，抬手一指门外，刘旭会意点头。",
     "冯西辉命令刘旭跟踪叫化子，查看其落脚处",
     "冯检校对刘掌柜沉声吩咐道：“你跟上去，盯住他，看他何处落脚！”", None),
    (5, "刘旭返身入内间，提了把刀出来；冯西辉皱眉摆手，刘旭讪讪放下刀，闪身出了店门。",
     "刘旭按吩咐出门跟踪（未带刀）",
     "刘掌柜点点头，先返回内间，片刻功夫竟提了把刀出来，冯检校皱眉道：“跟踪一个叫化子，"
     "还需要带刀？……放下！”刘掌柜讪讪地放下刀，闪身出了店门。", None),
    (5, "刘旭远远缀在提鱼的叫化子身后，沿南阳河畔的小径拐过一株柳树。",
     "刘旭尾随叫化子，查看其落脚处",
     "你跟上去，盯住他，看他何处落脚！", None),
    (5, "安立桐猛地一拍大腿，脸色涨红，惊叫出声。",
     "安立桐猜出冯西辉要用乞丐鱼目混珠",
     "安员外这才反应过来，惊叫道：“啊！我明白了，大人，莫非……莫非你想用这乞丐"
     "鱼目混珠？”", "d09"),
    (5, "冯西辉没有答话，拿起搁在面前那柄狭长略弯的刀，拇指一按卡簧，利刃呛啷一声"
        "弹出半尺，指肚轻轻拭过刀锋。",
     "冯西辉拿起绣春刀，感慨其威风何时能重现人间",
     "他拇指一按卡簧，利刃呛啷一声弹出半尺，冯检校的指肚轻轻拭过锋利的刀锋，"
     "喃喃自语道：“绣春刀啊绣春刀，要到几时你的威风才能重现人间？”", "d10"),
]

# ---- 12 条事实的承载（B 序号从 1 起；事实顺序 = 冻结顺序）----
CARRIERS = {
    "f01": [(2, "dialogue", "d01"), (3, "dialogue", "d02"), (1, "visual", None)],
    "f02": [(4, "dialogue", "d03"), (5, "dialogue", "d04")],
    "f03": [(6, "dialogue", "d05"), (7, "dialogue", "d06")],
    "f04": [(8, "dialogue", "d07")],
    "f05": [(9, "dialogue", "d08")],
    "f06": [(12, "visual", None)],
    "f07": [(13, "visual", None)],
    "f08": [(14, "visual", None)],
    "f09": [(15, "visual", None)],
    "f10": [(16, "visual", None), (17, "visual", None), (18, "visual", None)],
    "f11": [(19, "dialogue", "d09")],
    "f12": [(20, "dialogue", "d10"), (20, "visual", None)],
}


def build_candidate_view(base_plan: dict) -> dict:
    base_view, probs = pc.view_from_plan(base_plan)
    if probs:
        raise SystemExit("BASE_VIEW_INVALID %s" % probs)
    beats, beat_uids = [], []
    for i, (event, text, purpose, evidence, voice) in enumerate(BEATS, 1):
        uid = "b%02d" % i
        beat_uids.append(uid)
        beats.append({
            "uid": uid, "text": text, "purpose": purpose, "evidence": evidence,
            "source": {}, "event_uids": [base_view["frozen_events"][event - 1]],
            "voice_ref": ({"kind": "dialogue", "uid": voice} if voice else
                          {"kind": "visual", "uid": uid}),
        })
    dialogue_units = [{"uid": uid, "text": text, "source": {"text": text}}
                      for uid, _spk, text in VOICES]
    speakers = {uid: spk for uid, spk, _t in VOICES}
    bindings = []
    for fact in base_view["frozen_facts"]:
        refs = []
        for beat_no, kind, voice_uid in CARRIERS[fact["uid"]]:
            refs.append({"kind": kind,
                         "uid": voice_uid if kind == "dialogue" else beat_uids[beat_no - 1]})
        bindings.append({"fact_uid": fact["uid"], "carriers": refs})
    view = {
        "schema": base_view["schema"], "mode": base_view["mode"],
        "event_binding": base_view.get("event_binding") or "unknown",
        "frozen_facts": base_view["frozen_facts"],
        "frozen_events": base_view["frozen_events"],
        "beats": beats,
        "dialogue_units": dialogue_units,
        "narration_units": [],
        "screen_cards": [],
        "fact_bindings": bindings,
        "hook_bindings": base_view.get("hook_bindings") or {"spoken_uids": [], "carriers": []},
        "evidence_updates": [],
        "plan_basis": base_view["plan_basis"],
        "carrier_capacity": max(len(v) for v in CARRIERS.values()),
        "voice_speakers": speakers,
    }
    return view


def main():
    common.assert_frozen()
    base = common.load_plan()
    novel = common.load_novel()
    view = build_candidate_view(base)
    common.write_json(common.HERE / "candidate_view.json", view)
    plan, problems, changes = compile_reallocated_plan(base, view, novel_text=novel)
    common.write_json(common.HERE / "candidate_compile.json",
                      {"problems": problems, "changes": changes,
                       "rejected_candidate": changes.pop("rejected_candidate", None)})
    if plan is not None:
        common.write_json(common.HERE / "candidate_plan.json", plan)
    print(json.dumps({"accepted": plan is not None,
                      "problems": [p.get("code") for p in problems],
                      "voices": changes.get("voices", {}).get("after_lines"),
                      "sec": changes.get("voices", {}).get("after_sec"),
                      "han": changes.get("voices", {}).get("after_han"),
                      "unrepresentable": changes.get("voices", {}).get("unrepresentable_after"),
                      "representable": changes.get("voices", {}).get("representable_after")},
                     ensure_ascii=False, indent=1))
    for p in problems[:12]:
        print(" -", p.get("code"), "|", str(p.get("path") or "")[:40], "|",
              str(p.get("reason") or p.get("detail") or "")[:160])


if __name__ == "__main__":
    main()
