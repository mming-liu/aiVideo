# -*- coding: utf-8 -*-
"""S24 offline inspection & contract check for parsed ch2 storyboard."""
import json
import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
os.environ["OUTPUT_BASE"] = str(HERE / "output")
os.environ["STEP01_LOG_PATH"] = os.devnull
sys.path.insert(0, str(ROOT))

from step01_script_gen.validation import parse_response, _validate_script
from step01_script_gen.plan_feasibility import check_event_contract
from step01_script_gen.timecode import shot_content_floor

raw = json.loads((HERE / "s24_raw.json").read_text(encoding="utf-8"))
plan = json.loads((HERE / "candidate_plan.json").read_text(encoding="utf-8"))
novel = (HERE / "chapter2_text.txt").read_text(encoding="utf-8")

script = parse_response(raw["text"], novel)
print("parsed shots:", len(script.get("shots") or []) if script else None)
if script:
    (HERE / "s24_parsed.json").write_text(
        json.dumps(script, ensure_ascii=False, indent=1), encoding="utf-8"
    )
    total_dur = sum(float(s.get("duration_sec") or 0) for s in (script.get("shots") or []))
    print("total_dur:", round(total_dur, 3))
    for s in script["shots"]:
        fl = shot_content_floor(s)
        refs = s.get("plan_refs") or {}
        nar = (s.get("narration_segment") or "")[:35]
        print(
            f"  shot {s.get('index')}: dur={s.get('duration_sec')}s floor={fl}s "
            f"beats={refs.get('beats')} lines={refs.get('lines')} nar={nar!r}"
        )
    res = _validate_script(script, novel, outline=plan)
    print("_validate_script type:", type(res))
    if isinstance(res, dict):
        for k, v in res.items():
            if v:
                print("  prob", k, ":", v[:5] if isinstance(v, list) else v)
    elif isinstance(res, tuple):
        print("  tuple:", res[0], res[1][:10] if isinstance(res[1], list) else res[1])
    ec = check_event_contract(script, plan)
    print("check_event_contract:", ec)
