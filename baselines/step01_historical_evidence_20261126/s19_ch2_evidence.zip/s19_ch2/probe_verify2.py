﻿import json
d = json.load(open(r".tmp/s14b/runs/s12_ch2/verify.json", encoding="utf-8"))
r = d["record"]
print(json.dumps(r["facts"][0], ensure_ascii=False, indent=1)[:1200])
print("---- voice unit 0")
print(json.dumps(r["voice_units"][0], ensure_ascii=False, indent=1)[:600])
print("---- source_support 0")
print(json.dumps(r["source_support"][0], ensure_ascii=False, indent=1)[:400])
