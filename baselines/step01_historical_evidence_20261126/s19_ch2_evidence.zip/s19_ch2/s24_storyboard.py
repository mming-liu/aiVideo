# -*- coding: utf-8 -*-
"""S24: Guarded real storyboard generation for ch2 candidate_plan (isolated)."""
import json
import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))

EXPECTED_ENDPOINT = "https://opencode.ai/inference/go/openai/v1/chat/completions"
CHAPTER_LEDGER = ROOT / ".tmp" / "s14b" / "quota_ch2.json"
BATCH_LEDGER = HERE / "quota_s24_ch2.json"
PLAN_PATH = HERE / "candidate_plan.json"
NOVEL_PATH = HERE / "chapter2_text.txt"
OUT_PATH = HERE / "s24_raw.json"
REQ_PATH = HERE / "s24_requests.json"

if BATCH_LEDGER.exists():
    raise SystemExit(f"batch ledger exists: {BATCH_LEDGER}")

os.environ["TEXT_SEND_QUOTA_FILE"] = str(BATCH_LEDGER)
os.environ["OUTPUT_BASE"] = str(HERE / "output")
os.environ["STEP01_LOG_PATH"] = str(HERE / "s24_step01.log")
os.environ.pop("STEP01_READ_ONLY", None)

from _text_gen import chapter_quota as lg  # noqa: E402


def _json(p: Path):
    return json.loads(p.read_text(encoding="utf-8"))


def main():
    max_posts = 6
    rid = lg.reserve(CHAPTER_LEDGER, max_posts, tag=BATCH_LEDGER.name)
    BATCH_LEDGER.write_text(
        json.dumps({"max": max_posts, "used": 0, "attempts": []}, ensure_ascii=False),
        encoding="utf-8",
    )
    summary = {"success": False, "error": "", "chars": 0, "requests": []}
    try:
        import shared.config  # noqa: F401
        from _text_gen.agent_plan_provider import chat_completions_url, is_subscription_endpoint
        from _text_gen.config import TextGenCfg

        base = str(os.environ.get("AGENT_PLAN_TEXT_BASE_URL") or "")
        if (
            TextGenCfg.PROVIDER != "agent_plan"
            or not base
            or chat_completions_url(base) != EXPECTED_ENDPOINT
            or not is_subscription_endpoint(base)
        ):
            raise SystemExit(f"channel preflight failed: provider={TextGenCfg.PROVIDER} base={base}")

        from step01_script_gen.orchestrator import generation
        from step01_script_gen.orchestrator import runtime as rt

        plan = _json(PLAN_PATH)
        novel = NOVEL_PATH.read_text(encoding="utf-8")
        original = rt.create_service

        class _Proxy:
            def __init__(self):
                self.real = original()

            def generate(self, req):
                summary["requests"].append(
                    {
                        "schema": (req.json_schema or {}).get("name"),
                        "model": req.model,
                        "system_prompt": req.system_prompt,
                        "user_prompt": req.user_prompt,
                    }
                )
                return self.real.generate(req)

        rt.create_service = lambda *a, **k: _Proxy()
        try:
            raw = generation.gen_spy_script(novel, outline=plan, timeout_sec=600)
        finally:
            rt.create_service = original
        summary.update(success=True, chars=len(raw or ""), text=str(raw or ""))
    except BaseException as exc:  # noqa: BLE001
        summary["error"] = f"{type(exc).__name__}: {str(exc)[:500]}"
    finally:
        st = lg.settle_batch(CHAPTER_LEDGER, rid, BATCH_LEDGER)
        summary["settle"] = st
        OUT_PATH.write_text(
            json.dumps(summary, ensure_ascii=False, indent=1), encoding="utf-8"
        )
        if summary["requests"]:
            REQ_PATH.write_text(
                json.dumps(summary["requests"], ensure_ascii=False, indent=1),
                encoding="utf-8",
            )
    print(
        json.dumps(
            {k: summary.get(k) for k in ("success", "error", "chars", "settle")},
            ensure_ascii=False,
        )
    )
    if not summary["success"]:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
