# -*- coding: utf-8 -*-
"""S29: actual candidate entry from the verified unified plan (real calls, gated)."""
from __future__ import annotations
import json
import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / ".tmp" / "s26" / "real_sample"
os.environ["OUTPUT_BASE"] = str(OUT / "output")
os.environ["STEP01_LOG_PATH"] = str(OUT / "step01_candidates.log")
os.environ["PYTHONIOENCODING"] = "utf-8"
for key, value in {
    "DURATION_MIN_SEC": "60", "DURATION_MAX_SEC": "120",
    "DURATION_TARGET_MIN_SEC": "85", "DURATION_TARGET_MAX_SEC": "110",
    "STEP01_VOICE_ALLOCATION_MAX_LINES": "12",
    "STEP01_VOICE_ALLOCATION_MAX_HAN": "360",
    "SCRIPT_CANDIDATE_TOPK": "1",
}.items():
    os.environ[key] = value
sys.path.insert(0, str(ROOT))
from _text_gen.config import TextGenCfg
from _text_gen.agent_plan_provider import is_subscription_endpoint
assert TextGenCfg.PROVIDER == "agent_plan"
assert is_subscription_endpoint(TextGenCfg.AGENT_PLAN_TEXT_BASE_URL)

novel = (
    "夜班管理员把两本账册放进铁柜，对助手说：“钥匙交给我保管。”"
    "助手把钥匙递过去，说：“明早我来取。”"
    "管理员锁好柜门，把钥匙挂回腰间，关灯离开。"
    "助手工位上的台灯还亮着，抽屉缝里露出另一把备用钥匙。"
)
plan = json.loads((OUT / "plan.json").read_text(encoding="utf-8"))
from step01_script_gen.orchestrator.generation import _generate_script_candidates
try:
    cands = _generate_script_candidates(novel, None, None, plan)
except Exception as exc:                                           # noqa: BLE001
    (OUT / "candidates_result.json").write_text(json.dumps(
        {"ok": False, "error": "%s: %s" % (type(exc).__name__, exc)}, ensure_ascii=False,
        indent=1), encoding="utf-8")
    print(json.dumps({"ok": False, "error": "%s: %s" % (type(exc).__name__, exc)},
                     ensure_ascii=False))
    raise SystemExit(1)
score, script = cands[0]
(OUT / "candidate_storyboard.json").write_text(
    json.dumps(script, ensure_ascii=False, indent=1), encoding="utf-8")
from step01_script_gen.plan_feasibility import check_event_contract
ok, violations, declared = check_event_contract(script, plan, require_declaration=True)
print(json.dumps({"ok": True, "score": score.get("total"), "shots": len(script.get("shots") or []),
                  "total": sum(float(s.get("duration_sec") or 0) for s in script.get("shots") or []),
                  "contract_ok": ok, "violations": violations[:5], "declared": declared},
                 ensure_ascii=False, indent=1))
