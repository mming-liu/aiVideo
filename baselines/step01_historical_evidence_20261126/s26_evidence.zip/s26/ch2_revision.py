# -*- coding: utf-8 -*-
"""S30: real over-120 structural revision on the ch2 candidate (one bounded attempt)."""
from __future__ import annotations
import json
import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / ".tmp" / "s26" / "ch2_story"
os.environ["OUTPUT_BASE"] = str(OUT / "output")
os.environ["STEP01_LOG_PATH"] = str(OUT / "step01_regen.log")
os.environ["PYTHONIOENCODING"] = "utf-8"
for key, value in {
    "DURATION_MIN_SEC": "60", "DURATION_MAX_SEC": "120",
    "DURATION_TARGET_MIN_SEC": "85", "DURATION_TARGET_MAX_SEC": "110",
    "STEP01_VOICE_ALLOCATION_MAX_LINES": "12",
    "STEP01_VOICE_ALLOCATION_MAX_HAN": "360",
}.items():
    os.environ[key] = value
sys.path.insert(0, str(ROOT))
from _text_gen.config import TextGenCfg
from _text_gen.agent_plan_provider import is_subscription_endpoint
assert TextGenCfg.PROVIDER == "agent_plan"
assert is_subscription_endpoint(TextGenCfg.AGENT_PLAN_TEXT_BASE_URL)

plan = json.loads((ROOT / ".tmp" / "s26" / "ch2_verified_plan.json").read_text(encoding="utf-8"))
novel = (ROOT / ".tmp" / "s19_ch2" / "chapter2_text.txt").read_text(encoding="utf-8")
script = json.loads((OUT / "candidate_storyboard.json").read_text(encoding="utf-8"))
from step01_script_gen.outline import outline_to_anchor
from step01_script_gen.orchestrator.runtime import render_execution_contract
from step01_script_gen.orchestrator.regen import _regen_over_limit
revised = _regen_over_limit(
    script, novel, max_attempts=2,
    outline_anchor=outline_to_anchor(plan, novel),
    contract_block=render_execution_contract(plan), plan=plan)
(OUT / "revised_storyboard.json").write_text(
    json.dumps(revised, ensure_ascii=False, indent=1), encoding="utf-8")
from step01_script_gen.plan_feasibility import check_event_contract
from step01_script_gen.main import _build_step01_quality_gate
ok, violations, declared = check_event_contract(revised, plan, require_declaration=True)
quality = _build_step01_quality_gate(revised, novel)
summary = {
    "changed": revised != script,
    "shots": len(revised.get("shots") or []),
    "total": sum(float(s.get("duration_sec") or 0) for s in revised.get("shots") or []),
    "contract_ok": ok, "declared": declared, "violations": violations[:5],
    "quality_blocking_categories": quality.get("blocking_categories"),
    "quality_hard": len(quality.get("hard") or []),
    "quality_visual": len(quality.get("visual_risk") or []),
}
(OUT / "revision_result.json").write_text(json.dumps(summary, ensure_ascii=False, indent=1),
                                         encoding="utf-8")
print(json.dumps(summary, ensure_ascii=False, indent=1))
