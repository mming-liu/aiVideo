# -*- coding: utf-8 -*-
"""Verify the compacted ch2 plan through the real VerificationController."""
from __future__ import annotations
import json
import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / ".tmp" / "s26"
os.environ["OUTPUT_BASE"] = str(OUT / "compact_output")
os.environ["STEP01_LOG_PATH"] = str(OUT / "compact_verify.log")
os.environ["PYTHONIOENCODING"] = "utf-8"
for key, value in {
    "DURATION_MIN_SEC": "60", "DURATION_MAX_SEC": "120",
    "DURATION_TARGET_MIN_SEC": "85", "DURATION_TARGET_MAX_SEC": "110",
    "STEP01_VOICE_ALLOCATION_MAX_LINES": "12",
    "STEP01_VOICE_ALLOCATION_MAX_HAN": "360",
}.items():
    os.environ[key] = value
sys.path.insert(0, str(ROOT))
from _text_gen.config import TextGenCfg
from _text_gen.agent_plan_provider import is_subscription_endpoint
assert TextGenCfg.PROVIDER == "agent_plan"
assert is_subscription_endpoint(TextGenCfg.AGENT_PLAN_TEXT_BASE_URL)

plan = json.loads((OUT / "ch2_compact_plan.json").read_text(encoding="utf-8"))
novel = (ROOT / ".tmp" / "s19_ch2" / "chapter2_text.txt").read_text(encoding="utf-8")
from shared.call_ledger import set_ledger_path
set_ledger_path(OUT / "compact_calls.jsonl")
from step01_script_gen.unified_plan import _attach_verification
verified, problems, meter = _attach_verification(plan, novel, max_verifications=4)
summary = {
    "ok": verified is not None,
    "problems": [{"code": p.get("code"), "reason": str(p.get("reason"))[:200]}
                 for p in problems],
    "meter": meter,
    "beats": len((verified or plan).get("shot_beats") or []),
    "voices": len((verified or plan).get("voice_units") or []),
    "facts": len((verified or plan).get("required_facts") or []),
}
if verified is not None:
    (OUT / "ch2_compact_verified_plan.json").write_text(
        json.dumps(verified, ensure_ascii=False, indent=1), encoding="utf-8")
    from shared.content_verification import plan_digest_of
    summary["plan_digest"] = plan_digest_of(verified)
    summary["verification_status"] = verified["plan_verification"].get("status")
print(json.dumps(summary, ensure_ascii=False, indent=1))
