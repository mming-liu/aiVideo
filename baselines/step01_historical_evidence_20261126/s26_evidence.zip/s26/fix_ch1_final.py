# -*- coding: utf-8 -*-
"""Build a deterministic, frame-complete chapter-1 candidate for review."""
from __future__ import annotations
import copy
import json
from pathlib import Path

SRC = Path(".tmp/s26/ch1_fixed.json")
DST = Path(".tmp/s26/ch1_final.json")
s = json.loads(SRC.read_text(encoding="utf-8"))
by = {str(x.get("index")): x for x in s["shots"]}


def kf(desc, stage, t, dur):
    return {"desc": desc, "stage": stage, "t_sec": t,
            "time_ratio": round(t / dur, 4)}


# shot 4: entry gets its own frame; 4 segments / 4 frames
x = by["4"]
x["duration_sec"] = x["duration"] = 4.0
x["motion_desc"] = (
    "0-1.5秒：水面平静，小舟轻晃，公子仰卧美人伏身；"
    "1.5-2.2秒：水面炸开，湿透人影显露，按舷窜出；"
    "2.2-3.0秒：人影蹲踞船头，小舟猛沉；"
    "3.0-4.0秒：美人歪倒抓舷，公子仰卧未及反应")
x["keyframes"] = [
    kf("水面平静，船头公子仰卧，舱中美人伏身", "pre", 0.75, 4.0),
    kf("水面炸开，湿透人影显露，半个身子窜出水面", "climax", 1.85, 4.0),
    kf("湿透人影蹲踞船头，小舟猛沉", "approach", 2.60, 4.0),
    kf("美人歪倒抓舷，公子仰卧未及反应", "react", 3.50, 4.0),
]
base = x["frame_layouts"]["kfs"]
x["frame_layouts"]["kfs"] = [
    copy.deepcopy(base[0]),
    copy.deepcopy(base[1]),
    copy.deepcopy(base[1]),
    copy.deepcopy(base[1]),
]
x["frame_layouts"]["kfs"][1][-1]["states"] = ["显露", "窜出"]
x["frame_layouts"]["kfs"][2][-1]["states"] = ["蹲踞"]
x["frame_layouts"]["kfs"][3][-1]["states"] = ["蹲踞"]

# shot 5: strike and exit each get a frame; 4 segments / 4 frames
y = by["5"]
y["duration_sec"] = y["duration"] = 4.0
y["motion_desc"] = (
    "0-2秒：人影右手寒光刺入公子心口；"
    "2-2.4秒：人影推臂一送；"
    "2.4-3.0秒：双腿一弹倒纵入水，身影没入水中；"
    "3.0-4.0秒：水纹剧烈震荡，公子心口衣料暗红")
y["keyframes"] = [
    kf("湿透人影蹲踞船头右手扬起，短剑刺向仰卧公子心口", "climax", 1.20, 4.0),
    kf("短剑没入公子心口，公子胸口衣料洇开暗红", "climax", 2.20, 4.0),
    kf("人影双腿一弹倒纵入水，身影没入水中", "exit", 2.70, 4.0),
    kf("水纹剧烈震荡，公子心口暗红仰卧不动，美人歪倒抓舷", "react", 3.50, 4.0),
]
base = y["frame_layouts"]["kfs"]
y["frame_layouts"]["kfs"] = [
    copy.deepcopy(base[0]),
    copy.deepcopy(base[0]),
    copy.deepcopy(base[1]),
    copy.deepcopy(base[1]),
]
y["frame_layouts"]["kfs"][1][-1]["states"] = ["刺入"]
y["frame_layouts"]["kfs"][2][-1]["states"] = ["入水"]

# shot 11: add the 3-3.6s reaction frame
z = by["11"]
z["duration_sec"] = z["duration"] = 3.6
z["keyframes"] = [
    kf("青衣男子抬手蓄势，美人仰脸，公子仰卧心口暗红", "pre", 0.50, 3.6),
    kf("青衣男子反手一掌扇在美人脸上，美人头偏向一侧", "climax", 2.00, 3.6),
    kf("美人捂脸后退半步，青衣男子手掌停在半空", "react", 3.30, 3.6),
]
base = z["frame_layouts"]["kfs"]
z["frame_layouts"]["kfs"] = [
    copy.deepcopy(base[0]),
    copy.deepcopy(base[1]),
    copy.deepcopy(base[1]),
]
z["frame_layouts"]["kfs"][2][1]["states"] = ["披发", "捂脸", "后退"]

# hook: one layout per keyframe
h = s["hook"]
hk = h["frame_layouts"]["kfs"]
h["frame_layouts"]["kfs"] = [copy.deepcopy(hk[0]), copy.deepcopy(hk[0])]

DST.write_text(json.dumps(s, ensure_ascii=False, indent=1), encoding="utf-8")
print(json.dumps({"out": str(DST), "shots": len(s["shots"])}, ensure_ascii=False))
