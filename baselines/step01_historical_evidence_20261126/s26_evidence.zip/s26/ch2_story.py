# -*- coding: utf-8 -*-
"""S32/S29: complete storyboard from the S19 verified ch2 plan under the new band."""
from __future__ import annotations
import json
import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / ".tmp" / "s26" / "ch2_story"
OUT.mkdir(parents=True, exist_ok=True)
os.environ["OUTPUT_BASE"] = str(OUT / "output")
os.environ["STEP01_LOG_PATH"] = str(OUT / "step01.log")
os.environ["PYTHONIOENCODING"] = "utf-8"
for key, value in {
    "DURATION_MIN_SEC": "60", "DURATION_MAX_SEC": "120",
    "DURATION_TARGET_MIN_SEC": "85", "DURATION_TARGET_MAX_SEC": "110",
    "STEP01_VOICE_ALLOCATION_MAX_LINES": "12",
    "STEP01_VOICE_ALLOCATION_MAX_HAN": "360",
    "SCRIPT_CANDIDATE_TOPK": "1",
}.items():
    os.environ[key] = value
sys.path.insert(0, str(ROOT))
from _text_gen.config import TextGenCfg
from _text_gen.agent_plan_provider import is_subscription_endpoint
assert TextGenCfg.PROVIDER == "agent_plan"
assert is_subscription_endpoint(TextGenCfg.AGENT_PLAN_TEXT_BASE_URL)

plan = json.loads((ROOT / ".tmp" / "s19_ch2" / "candidate_plan.json").read_text(encoding="utf-8"))
novel = (ROOT / ".tmp" / "s19_ch2" / "chapter2_text.txt").read_text(encoding="utf-8")
from shared.call_ledger import set_ledger_path
set_ledger_path(OUT / "calls.jsonl")
from step01_script_gen.orchestrator.generation import _generate_script_candidates
try:
    cands = _generate_script_candidates(novel, None, None, plan)
except Exception as exc:                                           # noqa: BLE001
    (OUT / "result.json").write_text(json.dumps(
        {"ok": False, "error": "%s: %s" % (type(exc).__name__, exc)}, ensure_ascii=False,
        indent=1), encoding="utf-8")
    print(json.dumps({"ok": False, "error": "%s: %s" % (type(exc).__name__, exc)},
                     ensure_ascii=False))
    raise SystemExit(1)
score, script = cands[0]
(OUT / "candidate_storyboard.json").write_text(
    json.dumps(script, ensure_ascii=False, indent=1), encoding="utf-8")
from step01_script_gen.plan_feasibility import check_event_contract
from step01_script_gen.main import _build_step01_quality_gate
ok, violations, declared = check_event_contract(script, plan, require_declaration=True)
quality = _build_step01_quality_gate(script, novel)
summary = {
    "ok": True, "score": score.get("total"), "shots": len(script.get("shots") or []),
    "total": sum(float(s.get("duration_sec") or 0) for s in script.get("shots") or []),
    "contract_ok": ok, "declared": declared, "violations": violations[:5],
    "quality_blocking_categories": quality.get("blocking_categories"),
    "quality_hard": len(quality.get("hard") or []),
    "quality_visual": len(quality.get("visual_risk") or []),
}
(OUT / "result.json").write_text(json.dumps(summary, ensure_ascii=False, indent=1),
                                 encoding="utf-8")
print(json.dumps(summary, ensure_ascii=False, indent=1))
