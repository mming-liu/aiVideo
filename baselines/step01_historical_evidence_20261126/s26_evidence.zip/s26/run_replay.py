# -*- coding: utf-8 -*-
"""S28: run the external replay tool for frozen ch1/ch2 under old/new bands."""
from __future__ import annotations
import json, os, subprocess, sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
HERE = ROOT / ".tmp" / "s26"
REPLAY = HERE / "replay"
REPLAY.mkdir(parents=True, exist_ok=True)
freeze = json.loads((HERE / "freeze.json").read_text(encoding="utf-8"))
inputs = {k: (ROOT / v["path"]).resolve() for k, v in freeze["inputs"].items()}
CASES = [
    ("ch1_old", "ch1_plan", "ch1_text", "ch1_original", 60, 90, 70, 80, 10, 280),
    ("ch1_new", "ch1_plan", "ch1_text", "ch1_original", 60, 120, 85, 110, 12, 360),
    ("ch2_old", "ch2_plan", "ch2_text", "ch2_parsed", 60, 90, 70, 80, 10, 280),
    ("ch2_new", "ch2_plan", "ch2_text", "ch2_parsed", 60, 120, 85, 110, 12, 360),
]
summary = {}
for name, plan_k, novel_k, script_k, dmin, dmax, tmin, tmax, lines, han in CASES:
    manifest = REPLAY / f"{name}.json"
    payload = {"plan": os.path.relpath(inputs[plan_k], REPLAY),
               "novel": os.path.relpath(inputs[novel_k], REPLAY),
               "script": os.path.relpath(inputs[script_k], REPLAY)}
    for key, label in (("plan", plan_k), ("novel", novel_k), ("script", script_k)):
        import hashlib
        payload[key + "_sha256"] = hashlib.sha256(inputs[label].read_bytes()).hexdigest()
    manifest.write_text(json.dumps(payload, ensure_ascii=False, indent=1), encoding="utf-8")
    out = REPLAY / f"out_{name}"
    if out.exists():
        raise SystemExit(f"refusing to overwrite {out}")
    env = dict(os.environ)
    env.update({"DURATION_MIN_SEC": str(dmin), "DURATION_MAX_SEC": str(dmax),
                "DURATION_TARGET_MIN_SEC": str(tmin), "DURATION_TARGET_MAX_SEC": str(tmax),
                "STEP01_VOICE_ALLOCATION_MAX_LINES": str(lines),
                "STEP01_VOICE_ALLOCATION_MAX_HAN": str(han)})
    proc = subprocess.run([sys.executable, str(ROOT / "tools" / "replay_duration_budget.py"),
                           "--manifest", str(manifest), "--output-base", str(out)],
                          cwd=str(ROOT), env=env, capture_output=True, text=True,
                          encoding="utf-8", errors="replace")
    if proc.returncode != 0:
        summary[name] = {"error": proc.stderr[-2000:] or proc.stdout[-2000:]}
        continue
    found = list(out.rglob("duration_replay.json"))
    if len(found) != 1:
        summary[name] = {"error": "report not found: %s" % found,
                         "stdout": proc.stdout[-1000:]}
        continue
    result_path = found[0]
    result = json.loads(result_path.read_text(encoding="utf-8"))
    summary[name] = {
        "report": str(result_path.relative_to(ROOT)),
        "duration_band": result["duration_band"],
        "script": result.get("script"),
    }
(HERE / "s28_replay_summary.json").write_text(
    json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
print(json.dumps(summary, ensure_ascii=False, indent=2))
