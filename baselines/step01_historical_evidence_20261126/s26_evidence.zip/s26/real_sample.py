# -*- coding: utf-8 -*-
"""S32: short controlled sample through the unified entry (real model + verification)."""
from __future__ import annotations
import json
import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / ".tmp" / "s26" / "real_sample"
OUT.mkdir(parents=True, exist_ok=True)
os.environ["OUTPUT_BASE"] = str(OUT / "output")
os.environ["STEP01_LOG_PATH"] = str(OUT / "step01.log")
os.environ["PYTHONIOENCODING"] = "utf-8"
for key, value in {
    "DURATION_MIN_SEC": "60", "DURATION_MAX_SEC": "120",
    "DURATION_TARGET_MIN_SEC": "85", "DURATION_TARGET_MAX_SEC": "110",
    "STEP01_VOICE_ALLOCATION_MAX_LINES": "12",
    "STEP01_VOICE_ALLOCATION_MAX_HAN": "360",
    "STEP01_PLAN_MODE": "unified",
}.items():
    os.environ[key] = value
sys.path.insert(0, str(ROOT))

from _text_gen.config import TextGenCfg
from _text_gen.agent_plan_provider import is_subscription_endpoint
assert TextGenCfg.PROVIDER == "agent_plan"
assert is_subscription_endpoint(TextGenCfg.AGENT_PLAN_TEXT_BASE_URL)

novel = (
    "夜班管理员把两本账册放进铁柜，对助手说：“钥匙交给我保管。”"
    "助手把钥匙递过去，说：“明早我来取。”"
    "管理员锁好柜门，把钥匙挂回腰间，关灯离开。"
    "助手工位上的台灯还亮着，抽屉缝里露出另一把备用钥匙。"
)
from shared.call_ledger import set_ledger_path
set_ledger_path(OUT / "calls.jsonl")
from step01_script_gen.unified_plan import generate_unified_outline_result
result = generate_unified_outline_result(
    novel, cache_path=OUT / "chapter_outline.cache.json", source="lightweight",
    max_verifications=2)
(OUT / "result.json").write_text(json.dumps(result, ensure_ascii=False, indent=1),
                                 encoding="utf-8")
if isinstance(result.get("plan"), dict):
    (OUT / "plan.json").write_text(json.dumps(result["plan"], ensure_ascii=False, indent=1),
                                   encoding="utf-8")
print(json.dumps({
    "executable": result.get("executable"), "source": result.get("source"),
    "plan_source": result.get("plan_source"),
    "failure": result.get("failure"), "verification": result.get("verification"),
    "acceptance_codes": (result.get("acceptance") or {}).get("codes"),
    "voices": len((result.get("plan") or {}).get("voice_units") or []),
    "facts": len((result.get("plan") or {}).get("required_facts") or []),
    "beats": len((result.get("plan") or {}).get("shot_beats") or []),
    "plan_verification_status": ((result.get("plan") or {}).get("plan_verification") or {}).get("status"),
}, ensure_ascii=False, indent=1))
