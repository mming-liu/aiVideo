# -*- coding: utf-8 -*-
"""S32: one real unified planning call on frozen chapter 2 (new band, 12/360)."""
from __future__ import annotations
import json
import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / ".tmp" / "s26" / "real"
OUT.mkdir(parents=True, exist_ok=True)
os.environ["OUTPUT_BASE"] = str(OUT / "output")
os.environ["STEP01_LOG_PATH"] = str(OUT / "step01.log")
os.environ["PYTHONIOENCODING"] = "utf-8"
for key, value in {
    "DURATION_MIN_SEC": "60", "DURATION_MAX_SEC": "120",
    "DURATION_TARGET_MIN_SEC": "85", "DURATION_TARGET_MAX_SEC": "110",
    "STEP01_VOICE_ALLOCATION_MAX_LINES": "12",
    "STEP01_VOICE_ALLOCATION_MAX_HAN": "360",
    "STEP01_PLAN_MODE": "unified",
}.items():
    os.environ[key] = value
sys.path.insert(0, str(ROOT))

from _text_gen.config import TextGenCfg
from _text_gen.agent_plan_provider import is_subscription_endpoint
assert TextGenCfg.PROVIDER == "agent_plan", TextGenCfg.PROVIDER
assert is_subscription_endpoint(TextGenCfg.AGENT_PLAN_TEXT_BASE_URL)

from shared.call_ledger import set_ledger_path
set_ledger_path(OUT / "calls.jsonl")

from step01_script_gen.unified_plan import generate_unified_outline_result
source = sys.argv[1] if len(sys.argv) > 1 else "lightweight"
tag = "ch2_" + source
novel = (ROOT / ".tmp" / "s19_ch2" / "chapter2_text.txt").read_text(encoding="utf-8")
result = generate_unified_outline_result(
    novel, cache_path=OUT / ("chapter_outline_%s.cache.json" % source), source=source,
    max_verifications=2)
(OUT / ("result_%s.json" % tag)).write_text(
    json.dumps(result, ensure_ascii=False, indent=1), encoding="utf-8")
if isinstance(result.get("plan"), dict):
    (OUT / ("plan_%s.json" % tag)).write_text(
        json.dumps(result["plan"], ensure_ascii=False, indent=1), encoding="utf-8")
print(json.dumps({
    "executable": result.get("executable"),
    "source": result.get("source"),
    "plan_source": result.get("plan_source"),
    "failure": result.get("failure"),
    "acceptance_codes": (result.get("acceptance") or {}).get("codes"),
    "verification": result.get("verification"),
    "plan_digest": __import__("shared.content_verification", fromlist=["plan_digest_of"]
                              ).plan_digest_of(result.get("plan") or {}),
    "voices": len((result.get("plan") or {}).get("voice_units") or []),
    "facts": len((result.get("plan") or {}).get("required_facts") or []),
    "beats": len((result.get("plan") or {}).get("shot_beats") or []),
}, ensure_ascii=False, indent=1))
