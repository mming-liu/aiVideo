# -*- coding: utf-8 -*-
"""Rebuild the legal 116.5s candidate with a correct shot-12 exit timeline.

Other edits are the same evidence-bound wording fixes as `fix_legal_candidate.py`.
This script is a review artifact, not production code.
"""
from __future__ import annotations
import copy
import json
from pathlib import Path

SRC = Path(".tmp/s26/ch2_compact3_legal_116_5.json")
DST = Path(".tmp/s26/ch2_legal_fixed2.json")
script = json.loads(SRC.read_text(encoding="utf-8"))
shots = {str(s.get("index")): s for s in script["shots"]}
changes = []


def replace(shot_id, field, old, new):
    shot = shots[shot_id]
    value = shot.get(field)
    assert isinstance(value, str) and old in value, (shot_id, field, old, value)
    shot[field] = value.replace(old, new, 1)
    changes.append({"shot": shot_id, "field": field, "old": old, "new": new})


# shot 5: result-action process
replace("5", "motion_desc",
        "3-6秒：他狠狠一捶桌子，茶杯跳起，茶水溅出",
        "3-6秒：冯西辉拳头砸在桌面，茶杯跳起，茶水溅出")

# shot 9: kf1 must describe 3-6s only
shots["9"]["keyframes"][1]["desc"] = "张十三嘴唇开合，语气刻薄"
changes.append({"shot": "9", "field": "keyframes[1].desc",
                "new": shots["9"]["keyframes"][1]["desc"]})

# shot 11: visual basis requested by the audit
replace("11", "motion_desc",
        "3-6秒：他眼神警觉地扫过四人，打个哈哈",
        "3-6秒：切后院马车，车帘缝露出白布下杨旭的脸，与叫化子并置；他眼神警觉地扫过四人，打个哈哈")
shots["11"]["keyframes"][1]["desc"] = (
    "后院马车中白布下露出杨旭的脸，与叫化子并置；叫化子眼神警觉地扫过四人，打个哈哈")
changes.append({"shot": "11", "field": "keyframes[1].desc",
                "new": shots["11"]["keyframes"][1]["desc"]})

# shot 12: full 9s timeline, four frames, explicit holder / exit / occlusion
shot12 = shots["12"]
old = copy.deepcopy(shot12)
shot12["duration_sec"] = 9.0
shot12["duration"] = 9.0
shot12["ff_desc"] = "冯西辉沉脸坐在画左，抬手一指门外；刘旭坐在画右，会意点头"
shot12["motion_desc"] = (
    "0-3秒：冯西辉沉脸转向刘旭，抬手一指门外；"
    "3-3.75秒：刘旭点头起身；"
    "3.75-5.5秒：刘旭右手握刀，提刀出来，侧身退向门口，肩膀被门框遮住；"
    "5.5-9秒：冯西辉皱眉摆手，收回手指")
shot12["lf_desc"] = "冯西辉坐在画左，皱眉收手；刘旭已退到门外，身影被门框遮住"
shot12["keyframes"] = [
    {"desc": "冯西辉沉脸坐在画左，抬手一指门外；刘旭坐在画右，会意点头",
     "stage": "pre", "t_sec": 1.5, "time_ratio": round(1.5 / 9.0, 4)},
    {"desc": "刘旭点头起身，转向内间",
     "stage": "approach", "t_sec": 3.5, "time_ratio": round(3.5 / 9.0, 4)},
    {"desc": "门框外只余半截衣袖，肩膀被门框遮住",
     "stage": "exit", "t_sec": 5.5, "time_ratio": round(5.5 / 9.0, 4)},
    {"desc": "冯西辉坐在画左，皱眉摆手，收回手指",
     "stage": "react", "t_sec": 8.0, "time_ratio": round(8.0 / 9.0, 4)},
]
base_ff = copy.deepcopy(old["frame_layouts"]["ff"])
base_feng = copy.deepcopy(base_ff[0])
base_liu = copy.deepcopy(base_ff[1])
liu_knife = copy.deepcopy(base_liu)
liu_knife.update({"pose": "站立", "props": [], "states": ["点头起身"]})
liu_offscreen = copy.deepcopy(base_liu)
liu_offscreen.update({"on_screen": False, "position": "画外", "pose": "侧退",
                      "gaze_target": "无", "props": [],
                      "states": ["侧身退向门口", "被门框遮住"]})
liu_gone = copy.deepcopy(base_liu)
liu_gone.update({"on_screen": False, "position": "画外", "pose": "出门",
                 "gaze_target": "无", "props": [], "states": ["已退到门外"]})
feng_react = copy.deepcopy(base_feng)
feng_react["states"] = ["皱眉摆手", "收回手指"]
shot12["frame_layouts"] = {
    "ff": [base_feng, base_liu],
    "lf": [feng_react, liu_gone],
    "kfs": [
        [copy.deepcopy(base_feng), copy.deepcopy(base_liu)],
        [copy.deepcopy(base_feng), liu_knife],
        [copy.deepcopy(base_feng), liu_offscreen],
        [feng_react, liu_gone],
    ],
}
# 刘旭在 kf2 已不在可见画面；描述不再写名字，布局保留画外状态供离场判定。
shot12["keyframes"][2]["desc"] = "门框外只余半截衣袖，肩膀被门框遮住"
changes.append({"shot": "12", "field": "*", "old": "3-frame stale timeline",
                "new": "4-frame timeline with explicit holder and exit/occlusion"})

# shot 13/14: frame-window text
shots["13"]["keyframes"][1]["desc"] = "安立桐惊叫出声，身子前倾"
shots["13"]["keyframes"][2]["desc"] = "安立桐瞪大眼目光紧盯冯西辉，嘴唇开合"
shots["14"]["keyframes"][1]["desc"] = "冯西辉指肚拭过刀锋，利刃弹出半尺"
shots["14"]["keyframes"][2]["desc"] = "冯西辉喃喃自语，目光热切"
for sid in ("13", "14"):
    for i in (1, 2):
        changes.append({"shot": sid, "field": "keyframes[%d].desc" % i,
                        "new": shots[sid]["keyframes"][i]["desc"]})

DST.write_text(json.dumps(script, ensure_ascii=False, indent=1), encoding="utf-8")
Path(".tmp/s26/ch2_legal_fixed2_changes.json").write_text(
    json.dumps(changes, ensure_ascii=False, indent=1), encoding="utf-8")
print(json.dumps({"out": str(DST), "changes": len(changes)}, ensure_ascii=False))
