# -*- coding: utf-8 -*-
"""Targeted, evidence-bound wording fixes for the 116.5s legal candidate.

Only fields named by the 9 blocking issues are edited. Every replacement is asserted
so a stale candidate is rejected instead of silently producing a different edit.
"""
from __future__ import annotations
import json
from pathlib import Path

SRC = Path(".tmp/s26/ch2_compact3_legal_116_5.json")
DST = Path(".tmp/s26/ch2_legal_fixed.json")
script = json.loads(SRC.read_text(encoding="utf-8"))
shots = {str(s.get("index")): s for s in script["shots"]}
changes = []


def replace(shot_id, field, old, new):
    shot = shots[shot_id]
    value = shot.get(field)
    assert isinstance(value, str) and old in value, (shot_id, field, old, value)
    shot[field] = value.replace(old, new, 1)
    changes.append({"shot": shot_id, "field": field, "old": old, "new": new})


# shot 5: result-action process must appear in the motion timeline
replace("5", "motion_desc",
        "3-6秒：他狠狠一捶桌子，茶杯跳起，茶水溅出",
        "3-6秒：冯西辉拳头砸在桌面，茶杯跳起，茶水溅出")

# shot 9: kf1 at 3-6s must describe only 3-6s action
shot9_kf1 = shots["9"]["keyframes"][1]
assert shot9_kf1["desc"] == "张十三冷笑，嘴唇开合，安立桐额头冷汗"
shot9_kf1["desc"] = "张十三嘴唇开合，语气刻薄"
changes.append({"shot": "9", "field": "keyframes[1].desc", "old": "张十三冷笑，嘴唇开合，安立桐额头冷汗",
                "new": shot9_kf1["desc"]})

# shot 11: add the visual basis explicitly named by the audit
replace("11", "motion_desc",
        "3-6秒：他眼神警觉地扫过四人，打个哈哈",
        "3-6秒：切后院马车，车帘缝露出白布下杨旭的脸，与叫化子并置；他眼神警觉地扫过四人，打个哈哈")
shot11_kf1 = shots["11"]["keyframes"][1]
assert shot11_kf1["desc"] == "叫化子眼神警觉地扫过四人，打个哈哈"
shot11_kf1["desc"] = "后院马车中白布下露出杨旭的脸，与叫化子并置；叫化子眼神警觉地扫过四人，打个哈哈"
changes.append({"shot": "11", "field": "keyframes[1].desc", "old": "叫化子眼神警觉地扫过四人，打个哈哈",
                "new": shot11_kf1["desc"]})

# shot 12: explicit holder + exit/occlusion process
replace("12", "lf_desc", "刘旭放下刀，闪身出了店门，冯西辉皱眉收手",
        "刘旭右手把刀放在桌面，侧身退向门口，肩膀被门框遮住，闪身出门；冯西辉皱眉收手")
replace("12", "motion_desc", "6-9秒：冯西辉皱眉摆手，刘旭放下刀闪身出门",
        "6-9秒：冯西辉皱眉摆手，刘旭右手把刀放在桌面，侧身退向门口，肩膀被门框遮住，闪身出门")
shot12_kf2 = shots["12"]["keyframes"][2]
assert "放下刀" in shot12_kf2["desc"]
shot12_kf2["desc"] = "刘旭右手把刀放在桌面，侧身退向门口，肩膀被门框遮住，闪身出门"
changes.append({"shot": "12", "field": "keyframes[2].desc", "old": "刘旭放下刀，闪身出了店门，冯西辉皱眉收手",
                "new": shot12_kf2["desc"]})

# shot 13: kf1 / kf2 window text
shot13_kf1 = shots["13"]["keyframes"][1]
assert "猛地一拍大腿" in shot13_kf1["desc"]
shot13_kf1["desc"] = "安立桐惊叫出声，身子前倾"
shot13_kf2 = shots["13"]["keyframes"][2]
assert "惊叫出声" in shot13_kf2["desc"]
shot13_kf2["desc"] = "安立桐瞪大眼目光紧盯冯西辉，嘴唇开合"
changes += [
    {"shot": "13", "field": "keyframes[1].desc", "old": "安立桐猛地一拍大腿，脸色涨红",
     "new": shot13_kf1["desc"]},
    {"shot": "13", "field": "keyframes[2].desc", "old": "安立桐惊叫出声，身子前倾，瞪大眼看向画左冯西辉",
     "new": shot13_kf2["desc"]},
]

# shot 14: kf1 / kf2 window text
shot14_kf1 = shots["14"]["keyframes"][1]
assert "拇指按卡簧" in shot14_kf1["desc"]
shot14_kf1["desc"] = "冯西辉指肚拭过刀锋，利刃弹出半尺"
shot14_kf2 = shots["14"]["keyframes"][2]
assert "指肚拭过刀锋" in shot14_kf2["desc"]
shot14_kf2["desc"] = "冯西辉喃喃自语，目光热切"
changes += [
    {"shot": "14", "field": "keyframes[1].desc", "old": "冯西辉拇指按卡簧，利刃弹出半尺",
     "new": shot14_kf1["desc"]},
    {"shot": "14", "field": "keyframes[2].desc", "old": "冯西辉指肚拭过刀锋，目光热切",
     "new": shot14_kf2["desc"]},
]

DST.write_text(json.dumps(script, ensure_ascii=False, indent=1), encoding="utf-8")
Path(".tmp/s26/ch2_legal_fixed_changes.json").write_text(
    json.dumps(changes, ensure_ascii=False, indent=1), encoding="utf-8")
print(json.dumps({"out": str(DST), "changes": len(changes)}, ensure_ascii=False))
