# -*- coding: utf-8 -*-
"""S28 report: per-shot reading table + old/new issue diff."""
from __future__ import annotations
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
HERE = ROOT / ".tmp" / "s26"
summary = json.loads((HERE / "s28_replay_summary.json").read_text(encoding="utf-8"))
freeze = json.loads((HERE / "freeze.json").read_text(encoding="utf-8"))
inputs = {k: (ROOT / v["path"]).resolve() for k, v in freeze["inputs"].items()}


def load(key):
    return json.loads(inputs[key].read_text(encoding="utf-8-sig"))


def dur(shot):
    return float(shot.get("duration_sec") or shot.get("duration") or 0)


def row(shot, no):
    return ("| %s | %.2f | %d | %s | %s | %d | %d |" % (
        shot.get("index", no), dur(shot), len(str(shot.get("narration_segment") or "")),
        str(shot.get("scene") or shot.get("location") or "")[:18].replace("|", "／"),
        str(shot.get("main_subject") or "")[:18].replace("|", "／"),
        len(str(shot.get("motion_desc") or "")),
        len(shot.get("keyframes") or [])))


lines = ["# S28 新时长下的离线回放与逐镜评阅", "",
         "输入身份见 `.tmp/s26/freeze.json`；回放只读冻结副本，零模型调用。",
         "旧带 60–90／70–80／10 条／280 字；新带 60–120／85–110／12 条／360 字。", ""]
for name, script_key, final_key in (("ch1", "ch1_original", "ch1_final"),
                                    ("ch2", "ch2_parsed", "ch2_final")):
    old = summary[name + "_old"]["script"]
    new = summary[name + "_new"]["script"]
    lines += ["## %s" % name, "",
              "| 配置 | 正片秒数 | 时长问题 | 其他质量码 |", "|---|---:|---:|---:|",
              "| 旧 | %.1f | %d | %d |" % (old["total_sec"], len(old["duration_violations"]),
                                          len(old["other_quality_codes"])),
              "| 新 | %.1f | %d | %d |" % (new["total_sec"], len(new["duration_violations"]),
                                          len(new["other_quality_codes"])), ""]
    lines += ["旧带独有的时长问题：", ""]
    lines += ["- " + x for x in old["duration_violations"]] or ["- （无）"]
    lines += ["", "放宽后仍存在的问题（质量码，取交集差）：", ""]
    removed = set(old["other_quality_codes"]) - set(new["other_quality_codes"])
    kept = set(old["other_quality_codes"]) & set(new["other_quality_codes"])
    lines += ["- 新带消失：%s" % ("、".join(sorted(removed)) or "（无）"),
              "- 两带都在：%s" % ("、".join(sorted(kept)) or "（无）"), ""]
    source = load(script_key).get("shots") or []
    final = load(final_key).get("shots") or []
    lines += ["### %s 原始稿逐镜" % name, "",
              "| 镜 | 秒 | 发声字数 | 场景 | 主体 | 动作描述字数 | KF |",
              "|---:|---:|---:|---|---|---:|---:|"]
    lines += [row(s, i) for i, s in enumerate(source, 1)]
    lines += ["", "### %s 人工收口稿逐镜" % name, "",
              "| 镜 | 秒 | 发声字数 | 场景 | 主体 | 动作描述字数 | KF |",
              "|---:|---:|---:|---|---|---:|---:|"]
    lines += [row(s, i) for i, s in enumerate(final, 1)]
    lines += ["", "原始 %d 镜／%.2fs；收口 %d 镜／%.2fs。" % (
        len(source), sum(dur(s) for s in source), len(final), sum(dur(s) for s in final)), ""]

(HERE / "s28_report.md").write_text("\n".join(lines), encoding="utf-8")
print(HERE / "s28_report.md")
